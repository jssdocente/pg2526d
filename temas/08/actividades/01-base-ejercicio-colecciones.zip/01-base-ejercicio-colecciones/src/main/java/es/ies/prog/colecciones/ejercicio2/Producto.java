package es.ies.prog.colecciones.ejercicio2;

/*
 * EJERCICIO 2: Producto
 * 
 * Clase modelo que representa un producto del inventario.
 * 
 * Requisitos:
 * - Atributos id (int), nombre (String), stock (int).
 * - Constructor que reciba todos los campos.
 * - Getters (getId, getNombre, getStock).
 * - Setter (setStock).
 */
