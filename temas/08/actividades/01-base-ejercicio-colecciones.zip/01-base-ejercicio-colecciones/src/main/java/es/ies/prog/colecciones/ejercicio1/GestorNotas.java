package es.ies.prog.colecciones.ejercicio1;

/*
 * EJERCICIO 1: Gestor de Notas
 * 
 * Esta clase debe permitir gestionar las notas de un alumno utilizando una lista dinámica (ArrayList).
 * 
 * Requisitos:
 * - Un atributo privado para almacenar las notas (double).
 * - Un constructor que inicialice la lista.
 * - Método 'addNota(double)': añade una nota a la lista.
 * - Método 'calcularMedia()': calcula y retorna el promedio de las notas. (Si no hay notas, retorna 0).
 * - Método 'eliminarNotaMasBaja()': busca la nota más pequeña, la elimina de la lista y retorna true.
 * - Método 'totalNotas()': retorna el número de notas en la lista.
 */
