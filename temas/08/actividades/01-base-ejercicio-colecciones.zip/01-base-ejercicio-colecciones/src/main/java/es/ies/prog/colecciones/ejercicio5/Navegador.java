package es.ies.prog.colecciones.ejercicio5;

/*
 * EJERCICIO 5: Historial del Navegador
 * 
 * Clase que simula el botón atrás mediante una estructura LIFO utilizando Deque (pila).
 * 
 * Requisitos:
 * - Un atributo privado utilizando Deque<String>.
 * - Método 'navegar(String url)': añade la URL a la cima de la pila.
 * - Método 'retroceder()': elimina la URL de la cima y retorna la cadena eliminada (null si está vacía).
 * - Método 'getHistorial()': retorna una lista con todos los elementos actuales de la pila para su comprobación.
 */
