package es.ies.prog.colecciones.ejercicio2;

/*
 * EJERCICIO 2: Inventario
 * 
 * Clase que gestiona una lista de productos utilizando ArrayList.
 * 
 * Requisitos:
 * - Un atributo privado para almacenar los productos.
 * - Método 'agregar(Producto p)': añade un producto.
 * - Método 'buscarPorId(int id)': retorna el producto con ese ID o null.
 * - Método 'actualizarStock(String nombre, int stock)': busca el producto por nombre y cambia su stock. Retorna true si lo encontró.
 * - Método 'eliminar(int id)': elimina el producto de la lista basándose en su ID.
 * - Método 'totalProductos()': retorna cuántos productos hay en la lista del inventario.
 */
