package es.ies.prog.colecciones.ejercicio4;

/*
 * EJERCICIO 4: Diccionario de Traducción
 * 
 * Clase que asocia palabras en español con sus traducciones en inglés mediante un HashMap.
 * 
 * Requisitos:
 * - Un atributo privado HashMap con claves y valores de tipo String.
 * - Método 'guardarTraduccion(String espanol, String ingles)': guarda o actualiza la traducción de una palabra.
 * - Método 'traducir(String palabra)': busca y retorna la traducción de una palabra en español o null si no se encuentra.
 * - Método 'totalPalabras()': retorna la cantidad de entradas guardadas en el diccionario.
 */
