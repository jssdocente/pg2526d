package es.ies.prog.colecciones.ejercicio5;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class NavegadorTest {

    @Test
    public void testPilaLIFO() {
        // Arrange
        Navegador nav = new Navegador();
        nav.navegar("google.es");
        nav.navegar("ies.es");
        nav.navegar("github.com");
        
        // Act
        String atras1 = nav.retroceder();
        String atras2 = nav.retroceder();
        
        // Assert
        assertEquals("github.com", atras1, "Debería volver desde github (LIFO)");
        assertEquals("ies.es", atras2, "Tras github el anterior en la pila era el ies");
    }

    @Test
    public void testHistorialOrdenVacio() {
        // Arrange
        Navegador nav = new Navegador();
        
        // Act
        String resultado = nav.retroceder();
        
        // Assert
        assertNull(resultado, "Retroceder en historial vacío debe ser null");
        assertTrue(nav.getHistorial().isEmpty());
    }

    @Test
    public void testContenidoHistorial() {
        // Arrange
        Navegador nav = new Navegador();
        nav.navegar("url1");
        nav.navegar("url2");
        
        // Act
        List<String> hist = nav.getHistorial();
        
        // Assert
        // El orden en la pila muestra el más reciente primero (top of stack)
        assertEquals("url2", hist.get(0));
        assertEquals("url1", hist.get(1));
    }
}
