package org.example.logistica;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class LogisticaTest {

    @Test
    @DisplayName("FIFO: El Muelle de Carga debe respetar estrictamente el orden de llegada")
    public void testMuelleCargaFIFO() {
        MuelleCarga muelle = new MuelleCarga();
        Paquete p1 = new Paquete("P1", 10.0, "28001", 1);
        Paquete p2 = new Paquete("P2", 20.0, "28002", 2);
        Paquete p3 = new Paquete("P3", 30.0, "28003", 3);

        muelle.recibirPaquete(p1);
        muelle.recibirPaquete(p2);

        assertEquals("P1", muelle.cargarCamion().getTrackingID());

        muelle.recibirPaquete(p3);

        assertEquals("P2", muelle.cargarCamion().getTrackingID());
        assertEquals("P3", muelle.cargarCamion().getTrackingID());
        assertNull(muelle.cargarCamion(), "Si no hay paquetes, debe devolver null");
    }

    /*@Test
    @DisplayName("LIFO: La Mesa de Devoluciones debe devolver el último paquete apilado")
    public void testMesaDevolucionesLIFO() {
        MesaDevoluciones mesa = new MesaDevoluciones();
        Paquete p1 = new Paquete("P1", 10.0, "28001", 1);
        Paquete p2 = new Paquete("P2", 20.0, "28002", 2);
        Paquete p3 = new Paquete("P3", 30.0, "28003", 3);
        
        mesa.apilarPaquete(p1);
        mesa.apilarPaquete(p2);
        mesa.apilarPaquete(p3);
        
        assertEquals("P3", mesa.inspeccionar().getTrackingID(), "El último en entrar debe ser el primero en salir");
        assertEquals("P2", mesa.inspeccionar().getTrackingID());
        assertEquals("P1", mesa.inspeccionar().getTrackingID());
        assertNull(mesa.inspeccionar(), "Debe devolver null al vaciarse la pila");
    }*/

/*
    @Test
    @DisplayName("Comparable: Paquete debe compararse correctamente por peso")
    public void testPaqueteComparable() {
        Paquete ligero = new Paquete("L", 5.0, "100", 1);
        Paquete pesado = new Paquete("P", 15.0, "100", 1);
        Paquete igual = new Paquete("I", 5.0, "200", 2);
        
        assertTrue(ligero.compareTo(pesado) < 0, "5.0kg debe ser menor que 15.0kg");
        assertTrue(pesado.compareTo(ligero) > 0, "15.0kg debe ser mayor que 5.0kg");
        assertEquals(0, ligero.compareTo(igual), "Pesos iguales deben devolver 0");
    }
*/

/*
    @Test
    @DisplayName("Ordenación: Almacén debe ordenar listas por el orden natural (peso)")
    public void testAlmacenOrdenacionNatural() {
        Almacen almacen = new Almacen();
        List<Paquete> lista = new ArrayList<>(Arrays.asList(
            new Paquete("P1", 50.0, "111", 1),
            new Paquete("P2", 10.0, "222", 1),
            new Paquete("P3", 30.0, "333", 1),
            new Paquete("P4", 5.0, "444", 1)
        ));
        
        almacen.ordenarPorPeso(lista);
        
        assertEquals("P4", lista.get(0).getTrackingID());
        assertEquals("P2", lista.get(1).getTrackingID());
        assertEquals("P3", lista.get(2).getTrackingID());
        assertEquals("P1", lista.get(3).getTrackingID());
    }
*/

/*
    @Test
    @DisplayName("Comparator: Ordenar por urgencia (DESC) y por CP (ASC)")
    public void testComparadoresPersonalizados() {
        Paquete p1 = new Paquete("A", 10, "50000", 1);
        Paquete p2 = new Paquete("B", 10, "10000", 5);
        Paquete p3 = new Paquete("C", 10, "30000", 3);
        
        List<Paquete> lista = new ArrayList<>(Arrays.asList(p1, p2, p3));
        
        // Test Urgencia (5, 3, 1)
        lista.sort(new ComparadorUrgencia());
        assertEquals(5, lista.get(0).getUrgencia());
        assertEquals(3, lista.get(1).getUrgencia());
        assertEquals(1, lista.get(2).getUrgencia());
        
        // Test Código Postal (10000, 30000, 50000)
        lista.sort(new ComparadorCP());
        assertEquals("10000", lista.get(0).getCodigoPostal());
        assertEquals("30000", lista.get(1).getCodigoPostal());
        assertEquals("50000", lista.get(2).getCodigoPostal());
    }
*/

/*
    @Test
    @DisplayName("Maps: Hoja de Reparto debe gestionar zonas únicas y ordenadas (TreeMap)")
    public void testHojaRepartoTreeMap() {
        HojaReparto hoja = new HojaReparto();
        Paquete p1 = new Paquete("MAD-1", 1, "28001", 1);
        Paquete p2 = new Paquete("BCN-1", 1, "08001", 1);
        Paquete p3 = new Paquete("VAL-1", 1, "46001", 1);
        Paquete p4 = new Paquete("VAL-2", 2, "46001", 2);
        
        hoja.registrarEnvio(p1);
        hoja.registrarEnvio(p2);
        hoja.registrarEnvio(p3);
        
        assertEquals(3, hoja.totalZonas(), "Debe haber 3 zonas únicas");
        
        hoja.registrarEnvio(p4);
        assertEquals(3, hoja.totalZonas(), "Sobrescribir un CP no aumenta el número de zonas");
    }
*/

/*
    @Test
    @DisplayName("Generics: El ContenedorLogistico debe funcionar con cualquier Comparable (Paquete y Mantenimiento)")
    public void testContenedorGenerico() {
        // Probando con Paquete (Orden por peso: 5.0, 10.0, 50.0)
        ContenedorLogistico<Paquete> almacenPaquetes = new ContenedorLogistico<>();
        almacenPaquetes.añadir(new Paquete("P1", 50.0, "1", 1));
        almacenPaquetes.añadir(new Paquete("P2", 10.0, "1", 1));
        almacenPaquetes.añadir(new Paquete("P3", 5.0, "1", 1));
        
        assertEquals(50.0, almacenPaquetes.obtenerMasImportante().getPeso(), "El más 'importante' por peso es el de 50.0");
        
        // Probando con Mantenimiento (Orden por criticidad DESC: 10, 5, 2)
        ContenedorLogistico<Mantenimiento> gestionMantenimiento = new ContenedorLogistico<>();
        gestionMantenimiento.añadir(new Mantenimiento("M1", 100, 2));
        gestionMantenimiento.añadir(new Mantenimiento("M2", 500, 10)); // Más importante
        gestionMantenimiento.añadir(new Mantenimiento("M3", 200, 5));
        
        assertEquals(10, gestionMantenimiento.obtenerMasImportante().getCriticidad(), "La mayor criticidad es 10");
        assertEquals("M2", gestionMantenimiento.obtenerMasImportante().getId());
        
        List<Mantenimiento> ordenados = gestionMantenimiento.obtenerOrdenados();
        assertEquals(10, ordenados.get(0).getCriticidad(), "El primero en la lista ordenada debe ser el de criticidad 10");
        assertEquals(5, ordenados.get(1).getCriticidad());
        assertEquals(2, ordenados.get(2).getCriticidad());
    }
*/
}
