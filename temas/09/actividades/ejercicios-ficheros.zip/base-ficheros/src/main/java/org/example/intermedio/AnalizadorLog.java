package org.example.intermedio;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

/**
 * ACTIVIDAD 07: Análisis de Logs con Stream API
 * 
 * ENUNCIADO:
 * Dado un fichero servidor.log con formato [FECHA] [NIVEL] [MODULO] Mensaje, implementa:
 * 
 * 1. contarPorNivel(Path log) — Muestra cuántas entradas hay de cada nivel (INFO, WARN, ERROR).
 *    Usar Files.lines() y operaciones Stream.
 * 2. obtenerErrores(Path log) — Devuelve List<String> con las líneas de nivel ERROR.
 * 3. modulosAfectados(Path log) — Devuelve List<String> con módulos únicos que tienen 
 *    errores, ordenados alfabéticamente.
 * 4. primerasEntradas(Path log, int n) — Devuelve las primeras n entradas de nivel WARN o ERROR.
 * 5. tieneErroresCriticos(Path log, String palabra) — booleano si alguna línea ERROR 
 *    contiene la palabra clave.
 * 
 * Requisitos:
 * 1. Cada método abre su propio stream con try-with-resources.
 * 2. No usar bucles for/while. Solo operaciones Stream.
 */
public class AnalizadorLog {

    public void contarPorNivel(Path log) {
        // TODO: Usar Files.lines() y Collectors.groupingBy / counting
    }

    public List<String> obtenerErrores(Path log) {
        // TODO: Filtrar líneas que contengan [ERROR]
        return null;
    }

    public List<String> modulosAfectados(Path log) {
        // TODO: Extraer módulos de líneas con error, únicos y ordenados
        return null;
    }
}
