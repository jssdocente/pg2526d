package org.example.avanzado;

import java.io.Serializable;

/**
 * Entidad Producto para serialización.
 */
public class Producto implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int id;
    private String nombre;
    private double precio;
    private int stock;
    private String categoria;

    // TODO: Constructor, Getters, Setters y toString
}
