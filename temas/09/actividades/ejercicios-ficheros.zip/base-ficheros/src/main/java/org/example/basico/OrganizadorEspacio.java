package org.example.basico;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * ACTIVIDAD 01: Organizador de Espacio de Trabajo
 * 
 * ENUNCIADO:
 * Desarrolla la clase OrganizadorEspacio que, al ejecutarse, cree la siguiente estructura 
 * de directorios y ficheros si no existen ya:
 * 
 * proyecto/
 * ├── datos/
 * │   ├── alumnos.txt
 * │   └── notas.csv
 * ├── logs/
 * │   └── actividad.log
 * └── backups/
 * 
 * Requisitos:
 * 1. Si un directorio o fichero ya existe, mostrar un mensaje indicándolo (no lanzar error).
 * 2. Si se crea por primera vez, mostrar un mensaje de confirmación.
 * 3. Usar Files.createDirectories() para los directorios y Files.createFile() para los ficheros.
 * 4. Gestionar correctamente la IOException.
 * 5. Al final, mostrar un resumen: cuántos directorios y ficheros se han creado.
 */
public class OrganizadorEspacio {

    public static void main(String[] args) {
        inicializar();
    }

    public static void inicializar() {
        // TODO: Definir las rutas (proyecto, proyecto/datos, proyecto/logs, proyecto/backups)
        // TODO: Definir los ficheros (datos/alumnos.txt, datos/notas.csv, logs/actividad.log)
        
        System.out.println("=== Inicializando espacio de trabajo ===");
        
        // TODO: Crear directorios si no existen. Usar Files.createDirectories o Files.exists
        
        // TODO: Crear ficheros si no existen. Usar Files.createFile
        
        // TODO: Mostrar resumen de lo creado
    }
}
