package org.example.integrador;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * ACTIVIDAD 11: Sistema de Gestión de una Biblioteca (Integradora)
 * 
 * ENUNCIADO:
 * Desarrolla un sistema completo que integre todos los conceptos del tema:
 * 
 * Módulo 1 — Inicialización: Crea estructura de directorios biblioteca/datos, /logs, /exportaciones.
 * Módulo 2 — Catálogo desde CSV: Importar/Exportar catálogo de libros desde CSV usando Stream.
 * Módulo 3 — Préstamos con Serialización: Guardar y cargar objetos Prestamo serializados. 
 *           Lanzar excepción si un libro no está disponible.
 * Módulo 4 — Estadísticas con Stream: Libros más prestados y préstamos activos por socio.
 * Módulo 5 — Registro de actividad: Logger que registra cada operación en un fichero .log (APPEND).
 * 
 * Requisitos:
 * 1. Uso de try-with-resources en toda la persistencia.
 * 2. Diseño orientado a objetos con responsabilidad única.
 */
public class BibliotecaApp {

    public static void main(String[] args) {
        // TODO: Escenario de prueba principal
        System.out.println("Sistema de Gestión de Biblioteca Iniciado.");
    }
}
