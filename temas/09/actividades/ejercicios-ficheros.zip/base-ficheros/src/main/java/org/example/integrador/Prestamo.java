package org.example.integrador;

import java.io.Serializable;
import java.time.LocalDate;

public record Prestamo(int id, String isbnLibro, String nombreSocio, LocalDate fechaPrestamo, LocalDate fechaDevolucion) 
    implements Serializable {}
