package org.example.basico;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * ACTIVIDAD 02: Lector y Buscador de Ficheros de Texto
 * 
 * ENUNCIADO:
 * Crea la clase LectorBuscador que lea un fichero de texto y ofrezca dos funcionalidades:
 * 
 * 1. Mostrar el fichero numerado: Muestra cada línea precedida de su número de línea.
 * 2. Buscar una palabra: Muestra todas las líneas que contienen una palabra dada 
 *    (búsqueda case-insensitive), indicando el número de línea.
 * 
 * Requisitos:
 * 1. El nombre del fichero y la palabra de búsqueda se pasan como argumentos al main.
 * 2. Si el fichero no existe, mostrar un mensaje claro y terminar.
 * 3. El número de línea en la visualización ocupa siempre 3 caracteres (formato %3d).
 * 4. Si la búsqueda no encuentra resultados, indicarlo explícitamente.
 * 5. Mostrar al final el total de líneas del fichero y el total de coincidencias encontradas.
 */
public class LectorBuscador {

    public static void main(String[] args) {
        Path ruta = Paths.get("data/poema.txt");
        mostrarNumerado(ruta);
        buscarPalabra(ruta, "tierra");
    }

    public static void mostrarNumerado(Path fichero) {
        // TODO: Leer todas las líneas (Files.readAllLines)
        // TODO: Mostrar cada línea con su número formateado (%3d)
    }

    public static void buscarPalabra(Path fichero, String palabra) {
        // TODO: Implementar búsqueda case-insensitive
        // TODO: Mostrar líneas coincidentes con su número
    }
}
