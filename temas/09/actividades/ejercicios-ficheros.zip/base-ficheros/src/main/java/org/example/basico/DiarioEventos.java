package org.example.basico;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * ACTIVIDAD 03: Diario de Eventos
 * 
 * ENUNCIADO:
 * Desarrolla la clase DiarioEventos con los siguientes métodos:
 * 
 * 1. registrar(String categoria, String mensaje) — Añade una entrada al fichero diario.log 
 *    con el formato: [YYYY-MM-DD HH:mm:ss] [CATEGORIA ] Mensaje
 * 2. mostrar() — Lee el diario y lo muestra por consola con todas sus entradas.
 * 3. mostrarPorCategoria(String categoria) — Muestra solo las entradas de una categoría concreta.
 * 4. contarPorCategoria() — Muestra cuántas entradas hay de cada categoría.
 * 
 * Requisitos:
 * 1. Si el fichero no existe, se crea automáticamente al registrar la primera entrada.
 * 2. La columna de categoría ocupa siempre 8 caracteres (rellenar con espacios).
 * 3. La fecha y hora se formatea con DateTimeFormatter.
 * 4. Usar StandardOpenOption.APPEND para no sobreescribir entradas anteriores.
 */
public class DiarioEventos {
    private static final Path FICHERO = Paths.get("data/diario.log");
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void registrar(String categoria, String mensaje) {
        // TODO: Formatear la línea "[FECHA] [CATEGORIA] Mensaje"
        // TODO: Escribir usando Files.write con StandardOpenOption.APPEND
    }

    public static void mostrar() {
        // TODO: Leer y mostrar todo el diario
    }

    public static void contarPorCategoria() {
        // TODO: Contar ocurrencias de cada categoría usando un Map o similar
    }
}
