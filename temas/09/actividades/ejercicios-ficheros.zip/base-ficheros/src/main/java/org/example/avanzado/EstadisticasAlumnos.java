package org.example.avanzado;

import org.example.intermedio.Alumno;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

/**
 * ACTIVIDAD 08: Estadísticas Avanzadas con Collectors
 * 
 * ENUNCIADO:
 * Utilizando el record Alumno(nombre, modulo, t1, t2, t3), implementa:
 * 
 * 1. notaMediaPorModulo(List<Alumno> alumnos) — Map<String, Double> con la media por módulo.
 * 2. alumnosPorModulo(List<Alumno> alumnos) — Map<String, List<String>> con nombres agrupados.
 * 3. particionarAprobadosSuspensos(List<Alumno> alumnos) — Map<Boolean, Long> con conteos 
 *    de aprobados y suspensos.
 * 4. rankingModulos(List<Alumno> alumnos) — Muestra cada módulo ordenado por su nota media.
 * 5. generarCsvResumen(List<Alumno> alumnos, Path destino) — Escribe un CSV con nombre,media,estado 
 *    usando Collectors.joining.
 * 
 * Requisitos:
 * 1. Todos los métodos deben usar exclusivamente Collectors (sin bucles).
 * 2. El CSV final debe estar ordenado por nota media descendente.
 */
public class EstadisticasAlumnos {

    public Map<String, Double> notaMediaPorModulo(List<Alumno> alumnos) {
        // TODO: Agrupar por módulo y calcular media
        return null;
    }

    public Map<Boolean, Long> particionAprobadosSuspensos(List<Alumno> alumnos) {
        // TODO: Usar partitioningBy
        return null;
    }

    public void generarCsvResumen(List<Alumno> alumnos, Path destino) {
        // TODO: Escribir CSV con Collectors.joining
    }
}
