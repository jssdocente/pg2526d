package org.example.intermedio;

public record Alumno(String nombre, double t1, double t2, double t3) {
    public double media() {
        // TODO: Calcular media manejando el caso de nota -1 (no evaluado)
        return 0;
    }
}
