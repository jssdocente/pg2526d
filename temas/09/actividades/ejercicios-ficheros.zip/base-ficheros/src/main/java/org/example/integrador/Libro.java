package org.example.integrador;

import java.io.Serializable;

public record Libro(String isbn, String titulo, String autor, int anio, boolean disponible) 
    implements Serializable {}
