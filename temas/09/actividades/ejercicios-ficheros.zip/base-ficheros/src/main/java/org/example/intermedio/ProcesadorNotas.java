package org.example.intermedio;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/**
 * ACTIVIDAD 06: Procesador de Notas CSV
 * 
 * ENUNCIADO:
 * Dado un fichero CSV de notas de alumnos (nombre,t1,t2,t3), desarrolla la clase ProcesadorNotas:
 * 
 * 1. cargarNotas(Path ruta) — Lee el CSV, salta cabecera y comentarios (#), parsea cada fila. 
 *    Si una nota está vacía, se almacena como -1 (no evaluada).
 * 2. mostrarTabla(List<Alumno> alumnos) — Muestra una tabla formateada con nombre, trimestres, 
 *    media y estado (APROBADO/SUSPENSO/PENDIENTE si hay nota -1).
 * 3. generarResumen(List<Alumno> alumnos) — Muestra total alumnos, aprobados, suspensos, 
 *    pendientes, nota media de clase, alumno con mejor y peor nota.
 * 4. exportarAprobados(List<Alumno> alumnos, Path destino) — Escribe un nuevo CSV con 
 *    alumnos aprobados (media >= 5), ordenados de mayor a menor nota.
 * 
 * Requisitos:
 * 1. La tabla muestra "---" si la nota es -1.
 * 2. El estado es PENDIENTE si hay un -1, APROBADO si media >= 5, SUSPENSO si < 5.
 * 3. Líneas malformadas se ignoran con un aviso en System.err.
 */
public class ProcesadorNotas {

    public List<Alumno> cargarNotas(Path ruta) {
        // TODO: Leer CSV, saltar comentarios (#) y cabecera
        // TODO: Parsear filas y manejar campos vacíos como -1
        return null;
    }

    public void mostrarTabla(List<Alumno> alumnos) {
        // TODO: Mostrar tabla formateada
    }

    public void exportarAprobados(List<Alumno> alumnos, Path destino) {
        // TODO: Filtrar aprobados y escribir a CSV ordenado
    }
}
