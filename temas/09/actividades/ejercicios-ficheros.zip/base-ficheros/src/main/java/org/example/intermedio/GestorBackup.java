package org.example.intermedio;

import java.io.*;
import java.nio.file.*;

/**
 * ACTIVIDAD 05: Copias de Seguridad con try-with-resources
 * 
 * ENUNCIADO:
 * Desarrolla la clase GestorBackup con estos métodos:
 * 
 * 1. copiarConTransformacion(Path origen, Path destino, String prefijo) — Copia el fichero 
 *    origen al destino, añadiendo el prefijo al principio de cada línea.
 * 2. anonimizar(Path entrada, Path salida) — Lee un CSV con estructura nombre,telefono,email,nota 
 *    y escribe un nuevo CSV donde el teléfono está enmascarado (XXX-XXX-XXX) 
 *    y el email muestra solo el dominio (***@gmail.com).
 * 3. contarLineasYPalabras(Path fichero) — Devuelve un int[] con {numLineas, numPalabras}.
 * 
 * Requisitos:
 * 1. Todos los métodos deben usar try-with-resources.
 * 2. En copiarConTransformacion, ambos recursos (lector y escritor) se declaran en el mismo try.
 * 3. En anonimizar, la máscara del email conserva el dominio.
 * 4. Las líneas vacías o comentarios (#) se copian sin transformar.
 */
public class GestorBackup {

    public static void copiarConTransformacion(Path origen, Path destino, String prefijo) {
        // TODO: Usar try-with-resources con BufferedReader y BufferedWriter
    }

    public static void anonimizar(Path entrada, Path salida) {
        // TODO: Enmascarar teléfono y email conservando el dominio
    }

    public static int[] contarLineasYPalabras(Path fichero) {
        // TODO: Retornar {numLineas, numPalabras}
        return new int[]{0, 0};
    }
}
