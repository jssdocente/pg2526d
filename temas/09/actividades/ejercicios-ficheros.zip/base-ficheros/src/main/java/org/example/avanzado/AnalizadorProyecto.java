package org.example.avanzado;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;

/**
 * ACTIVIDAD 10: Buscador Recursivo con Files.walk()
 * 
 * ENUNCIADO:
 * Desarrolla la clase AnalizadorProyecto que recibe la ruta raíz de un proyecto Java y ofrece:
 * 
 * 1. contarFicherosPorExtension(Path raiz) — Map<String, Long> con conteo por extensión 
 *    (.java, .xml, etc.).
 * 2. buscarFicheros(Path raiz, String patron) — List<Path> cuyos nombres contienen el patrón.
 * 3. calcularTamañoTotal(Path raiz) — long con el tamaño total en bytes.
 * 4. encontrarFicherosGrandes(Path raiz, long umbralKB) — List<Path> que superan el umbral, 
 *    ordenados de mayor a menor.
 * 5. generarInforme(Path raiz, Path informe) — Escribe un resumen en un fichero de texto 
 *    con fecha, totales y el Top 5 de ficheros más grandes.
 * 
 * Requisitos:
 * 1. Todos los métodos usan Files.walk() con try-with-resources.
 * 2. No usar bucles explícitos.
 */
public class AnalizadorProyecto {

    public Map<String, Long> contarFicherosPorExtension(Path raiz) {
        // TODO: Usar Files.walk() y Collectors.groupingBy
        return null;
    }

    public List<Path> encontrarFicherosGrandes(Path raiz, long umbralKB) {
        // TODO: Filtrar por tamaño y ordenar descendente
        return null;
    }

    public void generarInforme(Path raiz, Path informe) {
        // TODO: Generar resumen de análisis en fichero de texto
    }
}
