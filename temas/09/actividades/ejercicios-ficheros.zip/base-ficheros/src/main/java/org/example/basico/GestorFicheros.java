package org.example.basico;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * ACTIVIDAD 04: Gestor de Ficheros de un Proyecto
 * 
 * ENUNCIADO:
 * Crea la clase GestorFicheros con los siguientes métodos estáticos:
 * 
 * 1. listarDirectorio(Path dir) — Lista todos los ficheros mostrando: nombre, tamaño en KB, 
 *    y fecha de última modificación. Al final, muestra el total de ficheros y el tamaño total.
 * 2. copiarFichero(Path origen, Path destino) — Copia un fichero. Si el destino ya existe, 
 *    lo sobreescribe. Muestra el resultado.
 * 3. renombrar(Path fichero, String nuevoNombre) — Renombra un fichero en el mismo directorio.
 * 4. eliminarFicherosTmp(Path dir) — Elimina todos los ficheros del directorio que terminen 
 *    en .tmp, mostrando cuántos se eliminaron.
 * 
 * Requisitos:
 * 1. El listado muestra el tamaño con 1 decimal en KB: 1.5 KB.
 * 2. La fecha de modificación se muestra en formato dd/MM/yyyy.
 * 3. Si un directorio no existe, mostrar un error descriptivo.
 * 4. Usar DirectoryStream con filtro glob para eliminarFicherosTmp.
 */
public class GestorFicheros {

    public static void listarDirectorio(Path dir) {
        // TODO: Usar DirectoryStream para listar nombre, tamaño (KB) y fecha
    }

    public static void copiarFichero(Path origen, Path destino) {
        // TODO: Files.copy con REPLACE_EXISTING
    }

    public static void eliminarFicherosTmp(Path dir) {
        // TODO: Usar DirectoryStream con filtro glob "*.tmp" para borrar
    }
}
