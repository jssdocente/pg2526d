package org.example.avanzado;

import java.nio.file.Path;
import java.util.List;

/**
 * ACTIVIDAD 09: Serialización: Gestor de Inventario
 * 
 * ENUNCIADO:
 * Desarrolla un sistema de inventario para una tienda de tecnología:
 * 
 * 1. Clase Producto (id, nombre, precio, stock, categoria) que implemente Serializable.
 * 2. guardar(List<Producto> productos, Path fichero) — Serializa la lista completa.
 * 3. cargar(Path fichero) — Deserializa y devuelve la lista (o lista vacía si no existe).
 * 4. buscarPorCategoria(List<Producto> productos, String categoria) — Filtrado de lista.
 * 5. actualizarStock(List<Producto> productos, int id, int nuevoStock) — Modifica el stock 
 *    del producto por ID.
 * 
 * Requisitos:
 * 1. Producto debe declarar serialVersionUID = 1L.
 * 2. usar try-with-resources en cargar/guardar.
 * 3. Demostrar el ciclo completo en el main: crear -> guardar -> cargar -> modificar -> guardar.
 */
public class Inventario {

    public void guardar(List<Producto> productos, Path fichero) {
        // TODO: Usar ObjectOutputStream para serializar la lista
    }

    public List<Producto> cargar(Path fichero) {
        // TODO: Usar ObjectInputStream para deserializar
        return null;
    }
}
