package org.example.intermedio;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class AnalizadorLogTest {

    @TempDir
    Path tempDir;

    @Test
    void testFiltrarErrores() throws Exception {
        Path log = tempDir.resolve("servidor.log");
        Files.write(log, List.of(
            "[2026-03-15 08:00:01] [INFO ] [AUTH] Servidor OK",
            "[2026-03-15 08:07:44] [ERROR] [DB] Timeout",
            "[2026-03-15 08:12:20] [WARN ] [AUTH] Acceso fallido"
        ));

        AnalizadorLog analizador = new AnalizadorLog();
        List<String> errores = analizador.obtenerErrores(log);

        // TODO: Tras implementar, validar que solo hay 1 error
        // assertNotNull(errores);
        // assertEquals(1, errores.size());
        // assertTrue(errores.get(0).contains("Timeout"));
    }
}
