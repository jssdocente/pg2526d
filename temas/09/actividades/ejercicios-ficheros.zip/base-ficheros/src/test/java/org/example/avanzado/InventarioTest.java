package org.example.avanzado;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class InventarioTest {

    @TempDir
    Path tempDir;

    @Test
    void testSerializacionCicloCompleto() {
        Path dat = tempDir.resolve("inventario.dat");
        Inventario gestor = new Inventario();
        
        List<Producto> originales = new ArrayList<>();
        // originales.add(new Producto(1, "Raton", 10.0, 5, "Periferico"));
        
        // TODO: Tras implementar Producto e Inventario, probar ciclo
        // gestor.guardar(originales, dat);
        // List<Producto> recuperados = gestor.cargar(dat);
        // assertEquals(originales.size(), recuperados.size());
    }
}
