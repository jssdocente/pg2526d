package org.example.basico;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

public class GestorFicherosTest {

    @TempDir
    Path tempDir;

    @Test
    void testEliminarTemporales() throws Exception {
        Path f1 = Files.createFile(tempDir.resolve("datos.txt"));
        Path f2 = Files.createFile(tempDir.resolve("tmp1.tmp"));
        Path f3 = Files.createFile(tempDir.resolve("tmp2.tmp"));

        GestorFicheros.eliminarFicherosTmp(tempDir);

        assertTrue(Files.exists(f1));
        assertFalse(Files.exists(f2));
        assertFalse(Files.exists(f3));
    }

    @Test
    void testCopiarFichero() throws Exception {
        Path origen = Files.createFile(tempDir.resolve("origen.txt"));
        Files.writeString(origen, "Hola Mundo");
        Path destino = tempDir.resolve("copia.txt");

        GestorFicheros.copiarFichero(origen, destino);

        assertTrue(Files.exists(destino));
        assertEquals("Hola Mundo", Files.readString(destino));
    }
}
