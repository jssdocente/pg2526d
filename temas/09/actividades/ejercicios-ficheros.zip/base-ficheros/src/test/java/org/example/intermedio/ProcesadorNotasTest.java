package org.example.intermedio;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class ProcesadorNotasTest {

    @TempDir
    Path tempDir;

    @Test
    void testCargarNotasConCamposVacios() throws Exception {
        Path csv = tempDir.resolve("notas.csv");
        Files.write(csv, List.of(
            "# Comentario",
            "nombre,t1,t2,t3",
            "Ana,8.0,7.0,9.0",
            "Javier,3.5,4.0," // T3 vacío
        ));

        ProcesadorNotas procesador = new ProcesadorNotas();
        List<Alumno> alumnos = procesador.cargarNotas(csv);

        // TODO: Tras implementar la lógica, estos asserts deberían pasar
        // assertNotNull(alumnos);
        // assertEquals(2, alumnos.size());
        // assertEquals(-1, alumnos.get(1).t3());
    }
}
