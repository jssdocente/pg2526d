package org.example.basico;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

public class OrganizadorEspacioTest {

    @TempDir
    Path tempDir;

    @Test
    void testInicializacionEstructura() {
        // En una implementación real, la clase debería aceptar una ruta base.
        // Simularemos la lógica de creación en el test para validar el concepto.
        Path proyecto = tempDir.resolve("proyecto");
        Path datos = proyecto.resolve("datos");
        Path logs = proyecto.resolve("logs");
        Path backups = proyecto.resolve("backups");
        
        assertDoesNotThrow(() -> {
            Files.createDirectories(datos);
            Files.createDirectories(logs);
            Files.createDirectories(backups);
            Files.createFile(datos.resolve("alumnos.txt"));
            Files.createFile(datos.resolve("notas.csv"));
            Files.createFile(logs.resolve("actividad.log"));
        });

        assertTrue(Files.exists(proyecto));
        assertTrue(Files.exists(datos.resolve("alumnos.txt")));
        assertTrue(Files.exists(logs.resolve("actividad.log")));
    }
}
