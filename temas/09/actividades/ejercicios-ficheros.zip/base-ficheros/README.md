# Proyecto Base UT9: Ficheros en Java

Este proyecto contiene los esqueletos y ficheros de datos necesarios para realizar las actividades de la Unidad 9.

## Estructura del Proyecto

El proyecto está organizado por niveles de dificultad:

- **`org.example.basico`**: Actividades 01 a 04 (Inicialización, lectura básica, logs y gestión de archivos).
- **`org.example.intermedio`**: Actividades 05 a 07 (Try-with-resources, procesamiento de CSV y análisis con Streams).
- **`org.example.avanzado`**: Actividades 08 a 10 (Collectors, Serialización y recorrido recursivo).
- **`org.example.integrador`**: Actividad 11 (Sistema completo de Biblioteca).

## Datos de Prueba

Los ficheros necesarios para las actividades (como `poema.txt`, `notas.csv`, etc.) se encuentran en la carpeta `data/`.

## Cómo usar este esqueleto

Cada clase contiene comentarios `TODO` donde los alumnos deben implementar la lógica utilizando la API moderna de Java **NIO.2** (`java.nio.file`).

Se recomienda el uso de **try-with-resources** en todas las operaciones de entrada/salida para garantizar la correcta gestión de recursos.
