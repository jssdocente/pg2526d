package org.example.integrador;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * ACTIVIDAD 11: Sistema de Gestión de una Biblioteca (Integradora)
 * 
 * ENUNCIADO:
 * Desarrolla un sistema completo que integre todos los conceptos del tema:
 * 
 * Módulo 1 — Inicialización: Crea estructura de directorios biblioteca/datos, /logs, /exportaciones.
 * Módulo 2 — Catálogo desde CSV: Importar/Exportar catálogo de libros desde CSV usando Stream.
 * Módulo 3 — Préstamos con Serialización: Guardar y cargar objetos Prestamo serializados. 
 *           Lanzar excepción si un libro no está disponible.
 * Módulo 4 — Estadísticas con Stream: Libros más prestados y préstamos activos por socio.
 * Módulo 5 — Registro de actividad: Logger que registra cada operación en un fichero .log (APPEND).
 * 
 * Requisitos:
 * 1. Uso de try-with-resources en toda la persistencia.
 * 2. Diseño orientado a objetos con responsabilidad única.
 */
public class BibliotecaApp {

    public static void main(String[] args) {
        GestorBiblioteca gestor = new GestorBiblioteca();

        // 1. Inicializar catálogo
        List<Libro> catalogo = new ArrayList<>();
        catalogo.add(new Libro("123", "El Quijote", "Cervantes", 1605, true));
        catalogo.add(new Libro("456", "1984", "George Orwell", 1949, true));
        catalogo.add(new Libro("789", "El Hobbit", "Tolkien", 1937, false));
        
        gestor.exportarCatalogo(catalogo);
        
        // 2. Importar y mostrar
        List<Libro> importados = gestor.importarCatalogo();
        System.out.println("Libros importados:");
        importados.forEach(System.out::println);

        // 3. Gestionar préstamos
        List<Prestamo> prestamos = gestor.cargarPrestamos();
        try {
            Libro l = importados.get(0);
            gestor.realizarPrestamo(l, "Socio 1", prestamos);
            System.out.println("Préstamo realizado con éxito.");
        } catch (LibroNoDisponibleException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (IndexOutOfBoundsException e) {
            System.out.println("No hay libros en el catálogo.");
        }

        try {
            Libro l = importados.get(2); // El Hobbit (no disponible)
            gestor.realizarPrestamo(l, "Socio 2", prestamos);
        } catch (LibroNoDisponibleException e) {
            System.out.println("Capturada excepción esperada: " + e.getMessage());
        }

        gestor.guardarPrestamos(prestamos);

        // 4. Estadísticas
        System.out.println("\n--- Estadísticas ---");
        System.out.println("Préstamos activos por socio:");
        gestor.estadisticasPrestamosPorSocio(prestamos)
              .forEach((socio, cant) -> System.out.println(socio + ": " + cant));

        System.out.println("\nLibros más prestados:");
        gestor.librosMasPrestados(prestamos, importados).forEach(System.out::println);

        System.out.println("\nSistema de Gestión de Biblioteca Finalizado.");
    }
}
