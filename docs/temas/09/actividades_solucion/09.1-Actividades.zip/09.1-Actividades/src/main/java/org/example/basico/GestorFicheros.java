package org.example.basico;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * ACTIVIDAD 04: Gestor de Ficheros de un Proyecto
 * 
 * ENUNCIADO:
 * Crea la clase GestorFicheros con los siguientes métodos estáticos:
 * 
 * 1. listarDirectorio(Path dir) — Lista todos los ficheros mostrando: nombre, tamaño en KB, 
 *    y fecha de última modificación. Al final, muestra el total de ficheros y el tamaño total.
 * 2. copiarFichero(Path origen, Path destino) — Copia un fichero. Si el destino ya existe, 
 *    lo sobreescribe. Muestra el resultado.
 * 3. renombrar(Path fichero, String nuevoNombre) — Renombra un fichero en el mismo directorio.
 * 4. eliminarFicherosTmp(Path dir) — Elimina todos los ficheros del directorio que terminen 
 *    en .tmp, mostrando cuántos se eliminaron.
 * 
 * Requisitos:
 * 1. El listado muestra el tamaño con 1 decimal en KB: 1.5 KB.
 * 2. La fecha de modificación se muestra en formato dd/MM/yyyy.
 * 3. Si un directorio no existe, mostrar un error descriptivo.
 * 4. Usar DirectoryStream con filtro glob para eliminarFicherosTmp.
 */
public class GestorFicheros {

    public static void main(String[] args) {

        //mostrarNumerado(ruta);
        Path ruta = Paths.get("/Users/jssgarcia/Documents/Docente/Cursos/25-26/PROG/clase/UT9/EC/09.1-Actividades/src/main/java/org/example/avanzado");
        GestorFicheros.listarDirectorio(ruta);

        GestorFicheros.eliminarFicherosTmp(Paths.get(System.getProperty("java.io.tmpdir")));

    }

    public static void listarDirectorio(Path dir) {

        DateTimeFormatter FORMATO = DateTimeFormatter
                .ofPattern("dd/MM/yyyy")
                .withZone(ZoneId.systemDefault());

        System.out.println("Contenido de: " + dir.toString());
        System.out.println("──────────────────────────────────────────────────────");
        System.out.printf("%-31s %-10s %14s\n","Tamaño","Nombre","Modificado");
        System.out.println("──────────────────────────────────────────────────────");

        int totalFicheros = 0;
        double totalSize=0;

        try ( DirectoryStream<Path> listaFicheros = Files.newDirectoryStream(dir)) {

            for (Path fichero: listaFicheros) {
                try {
                    totalFicheros++;
                    BasicFileAttributes attr = Files.readAttributes(fichero, BasicFileAttributes.class);

                    String sizeKB = String.format("%.1f", attr.size() / 1024.0);
                    totalSize = totalSize + (attr.size() / 1024.0);
                    String fechaModificacion = FORMATO.format(attr.lastModifiedTime().toInstant());
                    System.out.printf("%-31s %7s KB %14s\n",fichero.getFileName(),sizeKB,fechaModificacion);

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

            System.out.println("──────────────────────────────────────────────────────");
            System.out.printf("%3s fichero(s) - Tamaño total: %7s KB",totalFicheros,String.format("%.1f", totalSize));

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public static void copiarFichero(Path origen, Path destino) {

        try {
            Files.copy(origen,destino,StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            System.out.println("ERROR al copiar el fichero " + origen + " al destino " + destino);
        }
    }

    public static void eliminarFicherosTmp(Path dir) {
        // TODO: Usar DirectoryStream con filtro glob "*.tmp" para borrar

        try(DirectoryStream<Path> ficheros = Files.newDirectoryStream(dir,"*.temp")) {

            for(Path fichero: ficheros) {
                Files.deleteIfExists(fichero);
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
