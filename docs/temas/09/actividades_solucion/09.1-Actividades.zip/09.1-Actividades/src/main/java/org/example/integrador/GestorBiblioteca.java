package org.example.integrador;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Stream;

public class GestorBiblioteca {
    private static final Path BASE_PATH = Paths.get("biblioteca");
    private static final Path DATOS_PATH = BASE_PATH.resolve("datos");
    private static final Path LOGS_PATH = BASE_PATH.resolve("logs");
    private static final Path EXPORT_PATH = BASE_PATH.resolve("exportaciones");
    
    private static final Path LIBROS_CSV = DATOS_PATH.resolve("libros.csv");
    private static final Path PRESTAMOS_SER = DATOS_PATH.resolve("prestamos.ser");
    private static final Path ACTIVIDAD_LOG = LOGS_PATH.resolve("actividad.log");

    public GestorBiblioteca() {
        inicializarEstructura();
    }

    /**
     * Módulo 1: Inicialización
     */
    private void inicializarEstructura() {
        try {
            Files.createDirectories(DATOS_PATH);
            Files.createDirectories(LOGS_PATH);
            Files.createDirectories(EXPORT_PATH);
            registrarActividad("Estructura de directorios inicializada.");
        } catch (IOException e) {
            System.err.println("Error al crear directorios: " + e.getMessage());
        }
    }

    /**
     * Módulo 2: Catálogo desde CSV
     */
    public List<Libro> importarCatalogo() {
        if (!Files.exists(LIBROS_CSV)) return new ArrayList<>();
        try (Stream<String> lineas = Files.lines(LIBROS_CSV)) {
            return lineas.skip(1) // Cabecera
                    .map(linea -> {
                        String[] campos = linea.split(",");
                        return new Libro(campos[0], campos[1], campos[2], 
                                       Integer.parseInt(campos[3]), 
                                       Boolean.parseBoolean(campos[4]));
                    })
                    .toList();
        } catch (IOException e) {
            registrarActividad("Error importando catálogo: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public void exportarCatalogo(List<Libro> libros) {
        try (PrintWriter pw = new PrintWriter(Files.newBufferedWriter(LIBROS_CSV))) {
            pw.println("isbn,titulo,autor,anio,disponible");
            libros.forEach(l -> pw.printf("%s,%s,%s,%d,%b%n", 
                    l.isbn(), l.titulo(), l.autor(), l.anio(), l.disponible()));
            registrarActividad("Catálogo exportado: " + libros.size() + " libros.");
        } catch (IOException e) {
            registrarActividad("Error exportando catálogo: " + e.getMessage());
        }
    }

    /**
     * Módulo 3: Préstamos con Serialización
     */
    public void guardarPrestamos(List<Prestamo> prestamos) {
        try (ObjectOutputStream oos = new ObjectOutputStream(Files.newOutputStream(PRESTAMOS_SER))) {
            oos.writeObject(prestamos);
            registrarActividad("Préstamos guardados: " + prestamos.size());
        } catch (IOException e) {
            registrarActividad("Error guardando préstamos: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public List<Prestamo> cargarPrestamos() {
        if (!Files.exists(PRESTAMOS_SER)) return new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(Files.newInputStream(PRESTAMOS_SER))) {
            return (List<Prestamo>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            registrarActividad("Error cargando préstamos: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public void realizarPrestamo(Libro libro, String socio, List<Prestamo> prestamosActuales) throws LibroNoDisponibleException {
        if (!libro.disponible()) {
            throw new LibroNoDisponibleException("El libro '" + libro.titulo() + "' no está disponible.");
        }
        int nuevoId = prestamosActuales.stream().mapToInt(Prestamo::id).max().orElse(0) + 1;
        Prestamo p = new Prestamo(nuevoId, libro.isbn(), socio, LocalDate.now(), null);
        prestamosActuales.add(p);
        registrarActividad("Préstamo realizado: " + libro.titulo() + " a " + socio);
    }

    /**
     * Módulo 4: Estadísticas con Stream
     */
    public Map<String, Long> estadisticasPrestamosPorSocio(List<Prestamo> prestamos) {
        return prestamos.stream()
                .filter(p -> p.fechaDevolucion() == null)
                .collect(java.util.stream.Collectors.groupingBy(Prestamo::nombreSocio, java.util.stream.Collectors.counting()));
    }

    public List<String> librosMasPrestados(List<Prestamo> prestamos, List<Libro> catalogo) {
        Map<String, Long> conteo = prestamos.stream()
                .collect(java.util.stream.Collectors.groupingBy(Prestamo::isbnLibro, java.util.stream.Collectors.counting()));
        
        return conteo.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(5)
                .map(entry -> catalogo.stream()
                        .filter(l -> l.isbn().equals(entry.getKey()))
                        .findFirst()
                        .map(Libro::titulo)
                        .orElse("Desconocido"))
                .toList();
    }

    /**
     * Módulo 5: Registro de actividad (Logger)
     */
    public void registrarActividad(String mensaje) {
        try (PrintWriter pw = new PrintWriter(Files.newBufferedWriter(ACTIVIDAD_LOG, 
                StandardOpenOption.CREATE, StandardOpenOption.APPEND))) {
            pw.printf("[%s] %s%n", java.time.LocalDateTime.now(), mensaje);
        } catch (IOException e) {
            System.err.println("Error en el logger: " + e.getMessage());
        }
    }
}
