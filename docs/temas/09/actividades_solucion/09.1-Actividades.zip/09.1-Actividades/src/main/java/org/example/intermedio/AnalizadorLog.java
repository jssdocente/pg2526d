package org.example.intermedio;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * ACTIVIDAD 07: Análisis de Logs con Stream API
 * 
 * ENUNCIADO:
 * Dado un fichero servidor.log con formato [FECHA] [NIVEL] [MODULO] Mensaje, implementa:
 * 
 * 1. contarPorNivel(Path log) — Muestra cuántas entradas hay de cada nivel (INFO, WARN, ERROR).
 *    Usar Files.lines() y operaciones Stream.
 * 2. obtenerErrores(Path log) — Devuelve List<String> con las líneas de nivel ERROR.
 * 3. modulosAfectados(Path log) — Devuelve List<String> con módulos únicos que tienen 
 *    errores, ordenados alfabéticamente.
 * 4. primerasEntradas(Path log, int n) — Devuelve las primeras n entradas de nivel WARN o ERROR.
 * 5. tieneErroresCriticos(Path log, String palabra) — booleano si alguna línea ERROR 
 *    contiene la palabra clave.
 * 
 * Requisitos:
 * 1. Cada método abre su propio stream con try-with-resources.
 * 2. No usar bucles for/while. Solo operaciones Stream.
 */
public class AnalizadorLog {

    public void contarPorNivel(Path log) {
        try (Stream<String> lineas = Files.lines(log)) {
            Map<String, Long> conteo = lineas
                    .filter(l -> l.contains("[INFO ]") || l.contains("[WARN ]") || l.contains("[ERROR]"))
                    .collect(Collectors.groupingBy(
                            linea -> {
                                if (linea.contains("[INFO ]")) return "INFO";
                                if (linea.contains("[WARN ]")) return "WARN";
                                if (linea.contains("[ERROR]")) return "ERROR";
                                return "OTROS";
                            },
                            Collectors.counting()
                    ));
            conteo.forEach((nivel, cantidad) -> System.out.println(nivel + ": " + cantidad));
        } catch (IOException e) {
            System.err.println("Error leyendo el archivo de log: " + e.getMessage());
        }
    }

    public List<String> obtenerErrores(Path log) {
        try (Stream<String> lineas = Files.lines(log)) {
            return lineas
                    .filter(linea -> linea.contains("[ERROR]"))
                    .toList();
        } catch (IOException e) {
            return List.of();
        }
    }

    public List<String> modulosAfectados(Path log) {
        try (Stream<String> lineas = Files.lines(log)) {
            return lineas
                    .filter(linea -> linea.contains("[ERROR]"))
                    .map(linea -> {
                        // Formato: [FECHA] [NIVEL] [MODULO] Mensaje
                        // Ejemplo: [2026-03-15 08:07:44] [ERROR] [DB] Timeout
                        int firstBracket = linea.indexOf("] [", linea.indexOf("] [") + 1);
                        if (firstBracket != -1) {
                            int start = linea.indexOf("[", firstBracket + 1);
                            int end = linea.indexOf("]", start + 1);
                            if (start != -1 && end != -1) {
                                return linea.substring(start + 1, end);
                            }
                        }
                        return "UNKNOWN";
                    })
                    .distinct()
                    .sorted()
                    .toList();
        } catch (IOException e) {
            return List.of();
        }
    }

    public List<String> primerasEntradas(Path log, int n) {
        try (Stream<String> lineas = Files.lines(log)) {
            return lineas
                    .filter(l -> l.contains("[WARN ]") || l.contains("[ERROR]"))
                    .limit(n)
                    .toList();
        } catch (IOException e) {
            return List.of();
        }
    }

    public boolean tieneErroresCriticos(Path log, String palabra) {
        try (Stream<String> lineas = Files.lines(log)) {


            return lineas
                    .filter(linea -> linea.contains("[ERROR]"))
                    .anyMatch(linea -> linea.contains(palabra));

        } catch (IOException e) {
            return false;
        }
    }
}
