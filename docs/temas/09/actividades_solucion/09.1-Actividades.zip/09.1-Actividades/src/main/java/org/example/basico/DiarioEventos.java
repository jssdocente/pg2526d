package org.example.basico;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * ACTIVIDAD 03: Diario de Eventos
 * 
 * ENUNCIADO:
 * Desarrolla la clase DiarioEventos con los siguientes métodos:
 * 
 * 1. registrar(String categoria, String mensaje) — Añade una entrada al fichero diario.log 
 *    con el formato: [YYYY-MM-DD HH:mm:ss] [CATEGORIA ] Mensaje
 * 2. mostrar() — Lee el diario y lo muestra por consola con todas sus entradas.
 * 3. mostrarPorCategoria(String categoria) — Muestra solo las entradas de una categoría concreta.
 * 4. contarPorCategoria() — Muestra cuántas entradas hay de cada categoría.
 * 
 * Requisitos:
 * 1. Si el fichero no existe, se crea automáticamente al registrar la primera entrada.
 * 2. La columna de categoría ocupa siempre 8 caracteres (rellenar con espacios).
 * 3. La fecha y hora se formatea con DateTimeFormatter.
 * 4. Usar StandardOpenOption.APPEND para no sobreescribir entradas anteriores.
 */
public class DiarioEventos {
    private static final Path FICHERO = Paths.get("data/diario.log");
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void main(String[] args) {

        //mostrarNumerado(ruta);
        DiarioEventos.registrar("INFO",  "Aplicación iniciada.");
        DiarioEventos.registrar("INFO",  "Usuario 'admin' ha iniciado sesión.");
        DiarioEventos.registrar("AVISO", "Disco al 85% de capacidad.");
        DiarioEventos.registrar("ERROR", "No se pudo conectar con la BBDD.");
        DiarioEventos.registrar("ERROR", "No se pudo conectar con la BBDD.");
        DiarioEventos.registrar("ERROR", "No se pudo conectar con la BBDD.");
        DiarioEventos.registrar("ERROR", "No se pudo conectar con la BBDD.");
        DiarioEventos.registrar("INFO",  "Conexión BBDD restablecida.");

        DiarioEventos.mostrar();
        DiarioEventos.contarPorCategoria();

    }

    public static void registrar(String categoria, String mensaje) {

        String fecha = LocalDateTime.now().format(FMT);
        String texto = String.format("[%s] [%-8s] %s",fecha,categoria,mensaje);

        try {

        Files.write(FICHERO, List.of(texto), StandardCharsets.UTF_8, StandardOpenOption.CREATE,StandardOpenOption.APPEND);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void mostrar() {

        try(Stream<String> lineas = Files.lines(FICHERO,StandardCharsets.UTF_8)) {

            lineas.forEach(linea -> {
                System.out.println(linea);
            });

        } catch (Exception e) {
            System.out.println("ERROR: al procesar fichero " + FICHERO.toString() + " " + e.getMessage());
        }

    }

    public static void contarPorCategoria() {

        List<String> categorias = List.of("INFO","ERROR","AVISO");

        HashMap<String,Integer> infoResumen = new HashMap<>();

        //Forma imperativa
        try (var lineas = Files.lines(FICHERO,StandardCharsets.UTF_8)) {

            lineas.forEach(linea -> {

                for(String categoria: categorias) {
                    //Comprobar qué categoria tiene la linea
                    if (linea.contains("["+categoria)) {
                        //obtener el valor de clave --> obtiene el valor o si no existe, el valor por defecto.
                        int cantidadElementos = infoResumen.getOrDefault(categoria,0);
                        infoResumen.put(categoria, cantidadElementos+1);
                    }
                }
            });

        } catch (Exception e) {
            System.out.println("ERROR: al procesar fichero " + FICHERO.toString() + " " + e.getMessage());
        }

        //Mostrar la información obtenida
        System.out.println("Entradas por categoría:");
        for (String categoria: infoResumen.keySet()) {
            System.out.printf("%-8s : %d\n",categoria,infoResumen.get(categoria));
        }

    }
}
