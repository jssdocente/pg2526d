package org.example.intermedio;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Stream;

/**
 * ACTIVIDAD 06: Procesador de Notas CSV
 * 
 * ENUNCIADO:
 * Dado un fichero CSV de notas de alumnos (nombre,t1,t2,t3), desarrolla la clase ProcesadorNotas:
 * 
 * 1. cargarNotas(Path ruta) — Lee el CSV, salta cabecera y comentarios (#), parsea cada fila. 
 *    Si una nota está vacía, se almacena como -1 (no evaluada).
 * 2. mostrarTabla(List<Alumno> alumnos) — Muestra una tabla formateada con nombre, trimestres, 
 *    media y estado (APROBADO/SUSPENSO/PENDIENTE si hay nota -1).
 * 3. generarResumen(List<Alumno> alumnos) — Muestra total alumnos, aprobados, suspensos, 
 *    pendientes, nota media de clase, alumno con mejor y peor nota.
 * 4. exportarAprobados(List<Alumno> alumnos, Path destino) — Escribe un nuevo CSV con 
 *    alumnos aprobados (media >= 5), ordenados de mayor a menor nota.
 * 
 * Requisitos:
 * 1. La tabla muestra "---" si la nota es -1.
 * 2. El estado es PENDIENTE si hay un -1, APROBADO si media >= 5, SUSPENSO si < 5.
 * 3. Líneas malformadas se ignoran con un aviso en System.err.
 */
public class ProcesadorNotas {

    public static void main(String[] args) {

        ProcesadorNotas procesador = new ProcesadorNotas();
        List<Alumno> alumnos = procesador.cargarNotas(Paths.get("data","notas.csv"));
        procesador.mostrarTabla(alumnos);
        procesador.exportarAprobados(alumnos, Paths.get("data","notas_aprobados.csv"));
    }

    public List<Alumno> cargarNotas(Path ruta) {

        try (Stream<String> lineas = Files.lines(ruta)) {

            return lineas
                    .filter(linea -> !(linea.startsWith("#") || linea.isEmpty()))
                    .filter(linea -> !linea.startsWith("nombre,")) // Omitir cabecera explícitamente
                    .filter(linea -> linea.split(",").length >= 4)
                    .map(linea -> ProcesadorNotas.parsearAlumno(linea))
                    .toList();


        } catch (IOException e) {
            System.out.printf("ERROR cargarNotas: " + e.getMessage());
        }


        // TODO: Parsear filas y manejar campos vacíos como -1
        return null;
    }

    public void mostrarTabla(List<Alumno> alumnos) {
        
        if (alumnos == null || alumnos.isEmpty()) {
            System.out.println("No hay datos para mostrar.");
            return;
        }
        
        System.out.println("══════════════════════════════════════════════════════════════════");
        System.out.printf("%-25s %6s %6s %6s %8s  %-10s%n", "Nombre", "T1", "T2", "T3", "Media", "Estado");
        System.out.println("──────────────────────────────────────────────────────────────────");

        long aprobados = 0;
        long pendientes = 0;
        long suspensos = 0;
        double sumaMedias = 0;
        int alumnosConMedia = 0;
        Alumno mejorAlumno = null;

        for (Alumno a : alumnos) {
            String sT1 = a.formatNota(a.t1());
            String sT2 = a.formatNota(a.t2());
            String sT3 = a.formatNota(a.t3());
            double media = a.media();
            String sMedia = a.formatNota(media);
            String estado = a.estado();

            System.out.printf("%-25s %6s %6s %6s %8s   %-10s%n",
                    a.nombre(), sT1, sT2, sT3, sMedia, estado);

            switch (estado) {
                case "APROBADO" -> aprobados++;
                case "PENDIENTE" -> pendientes++;
                case "SUSPENSO" -> suspensos++;
            }

            if (media != -1) {
                sumaMedias += media;
                alumnosConMedia++;
                if (mejorAlumno == null || media > mejorAlumno.media()) {
                    mejorAlumno = a;
                }
            }
        }

        System.out.println("══════════════════════════════════════════════════════════════════");
        System.out.printf("Aprobados: %d  Pendientes: %d  Suspensos: %d%n", aprobados, pendientes, suspensos);
        
        double mediaClase = alumnosConMedia > 0 ? sumaMedias / alumnosConMedia : 0;
        String mejorInfo = mejorAlumno != null ? 
                String.format("%s (%.1f)", mejorAlumno.nombre(), mejorAlumno.media()) : "---";
        
        System.out.printf("Nota media de la clase: %.1f  |  Mejor: %s%n", mediaClase, mejorInfo);
    }

    public void exportarAprobados(List<Alumno> alumnos, Path destino) {

        try(BufferedWriter writer = Files.newBufferedWriter(destino)) {
            alumnos.stream()
                    .filter(a -> a.media() >= 5)
                    .sorted(new AlumnoComparator().reversed())
                    .forEach(a -> {
                        try {
                            writer.write(a.nombre() + "," + a.media() + "\n");
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    });


            //For tradicional
            for(Alumno a: alumnos) {

                if (a.media()<5)
                    continue;

                Collections.sort(alumnos,new AlumnoComparator().reversed());

                try {
                    writer.write(a.nombre() + "," + a.media() + "\n");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

        } catch (IOException e) {
            System.out.printf("ERROR exportarAprobados: " + e.getMessage());
        }
    }


    class AlumnoComparator implements Comparator<Alumno> {

        @Override
        public int compare(Alumno o1, Alumno o2) {
            if (o1.media()==o2.media()) return 0;
            return o1.media() > o2.media() ? -1 : 1;
        }
    }

    private static double parseDouble(String valor, double valorDefecto) {

        if (valor==null)
            return valorDefecto;

        try {
            return Double.parseDouble(valor);

        } catch (NumberFormatException ex) {
            return valorDefecto;
        }
    }

    private static Alumno parsearAlumno(String linea) {
        String[] c = linea.split(",");

        return new Alumno(c[0].trim(),
                parseDouble(c[1].trim(), -1),
                parseDouble(c[2].trim(), -1),
                parseDouble(c[3].trim(), -1)
        );
    }

}
