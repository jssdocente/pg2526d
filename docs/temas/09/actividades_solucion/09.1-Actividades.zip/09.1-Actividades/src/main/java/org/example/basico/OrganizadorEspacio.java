package org.example.basico;

import org.apache.commons.io.FilenameUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

/**
 * ACTIVIDAD 01: Organizador de Espacio de Trabajo
 * 
 * ENUNCIADO:
 * Desarrolla la clase OrganizadorEspacio que, al ejecutarse, cree la siguiente estructura 
 * de directorios y ficheros si no existen ya:
 * 
 * proyecto/
 * ├── datos/
 * │   ├── alumnos.txt
 * │   └── notas.csv
 * ├── logs/
 * │   └── actividad.log
 * └── backups/
 * 
 * Requisitos:
 * 1. Si un directorio o fichero ya existe, mostrar un mensaje indicándolo (no lanzar error).
 * 2. Si se crea por primera vez, mostrar un mensaje de confirmación.
 * 3. Usar Files.createDirectories() para los directorios y Files.createFile() para los ficheros.
 * 4. Gestionar correctamente la IOException.
 * 5. Al final, mostrar un resumen: cuántos directorios y ficheros se han creado.
 */
public class OrganizadorEspacio {

    public static void main(String[] args) {
        inicializar();
    }

    public static void inicializar() {
        // TODO: Definir las rutas (proyecto, proyecto/datos, proyecto/logs, proyecto/backups)
        Path pathBase = Paths.get("Proyecto");
        Path pathFolderDatos = pathBase.resolve("datos");
        Path pathFolderLogs = pathBase.resolve("logs");
        Path pathFolderBackup = pathBase.resolve("backups");

        // TODO: Definir los ficheros (datos/alumnos.txt, datos/notas.csv, logs/actividad.log)
        
        System.out.println("=== Inicializando espacio de trabajo ===");

        String texto = "hola#javier#ramon jesus";
        String[] nombres = texto.split(" ");

        try {
            // TODO: Crear directorios si no existen. Usar Files.createDirectories o Files.exists
            List<Path> paths = List.of(
                    pathFolderDatos,
                    pathFolderBackup,
                    pathFolderLogs,
                    pathFolderDatos.resolve("alumnos.txt"),
                    pathFolderDatos.resolve("notas.csv"),
                    pathFolderLogs.resolve("actividad.log")
            );

            for (Path path : paths) {

                if (FilenameUtils.getExtension(path.toString()).isEmpty()) {
                    if (!Files.exists(path)) {
                        Files.createDirectories(path);
                        System.out.printf("[CREADO] Directorio: %s\n",path);
                    } else {
                        System.out.printf("[OK] Directorio ya existe: %s\n",path);
                    }
                } else {
                    if (!Files.exists(path)) {
                        Files.createFile(path);
                        System.out.printf("[CREADO] Fichero: %s\n",path);
                    } else {
                        System.out.printf("[OK] Ficheros ya existe: %s\n",path);
                    }
                }
            }

            if (!Files.exists(pathFolderDatos)) {
                Files.createDirectories(pathFolderDatos);
                System.out.printf("[CREADO] Directorio: %s",pathFolderDatos);
            } else {
                System.out.printf("[OK] Directorio ya existe: %s",pathFolderDatos);
            }

            if (!Files.exists(pathFolderLogs)) {
                Files.createDirectories(pathFolderLogs);
                System.out.printf("[CREADO] Directorio: %s",pathFolderLogs);
            }

            if (!Files.exists(pathFolderBackup)) {
                Files.createDirectories(pathFolderBackup);
                System.out.printf("[CREADO] Directorio: %s",pathFolderBackup);
            }

            // TODO: Crear ficheros si no existen. Usar Files.createFile

            // TODO: Mostrar resumen de lo creado


        } catch (IOException ex) {
            System.out.println("ERROR ");
        }
    }
}
