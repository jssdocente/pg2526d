package org.example.basico;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Stream;

/**
 * ACTIVIDAD 02: Lector y Buscador de Ficheros de Texto
 * 
 * ENUNCIADO:
 * Crea la clase LectorBuscador que lea un fichero de texto y ofrezca dos funcionalidades:
 * 
 * 1. Mostrar el fichero numerado: Muestra cada línea precedida de su número de línea.
 * 2. Buscar una palabra: Muestra todas las líneas que contienen una palabra dada 
 *    (búsqueda case-insensitive), indicando el número de línea.
 * 
 * Requisitos:
 * 1. El nombre del fichero y la palabra de búsqueda se pasan como argumentos al main.
 * 2. Si el fichero no existe, mostrar un mensaje claro y terminar.
 * 3. El número de línea en la visualización ocupa siempre 3 caracteres (formato %3d).
 * 4. Si la búsqueda no encuentra resultados, indicarlo explícitamente.
 * 5. Mostrar al final el total de líneas del fichero y el total de coincidencias encontradas.
 */
public class LectorBuscador {

    public static void main(String[] args) {
        Path ruta = Paths.get("data/poema.txt");

        //mostrarNumerado(ruta);
        buscarPalabra(ruta, "TieRra");
    }

    public static void mostrarNumerado(Path fichero) {
        // TODO: Leer todas las líneas (Files.readAllLines)
        try {
            //No es necesario cerrar el fichero, porque lo hace solo Java
            //  Abre fichero -> lee todas las lineas -> cierra el fichero
            List<String> lineas = Files.readAllLines(fichero, StandardCharsets.UTF_8);

            for (int i = 0; i < lineas.size(); i++) {
                System.out.printf("%d | %s\n", i + 1, lineas.get(i));
            }


            System.out.println("─────────────────────────────");
            System.out.printf("Total: %d líneas\n", lineas.size());

        } catch (NoSuchFileException ex) {
            System.out.println("ERROR: el fichero " + fichero.toString() + " no existe");
        } catch (IOException e) {
            System.out.println("ERROR: procesar fichero " + e.getMessage());
        }

        // TODO: Mostrar cada línea con su número formateado (%3d)
    }

    public static void buscarPalabra(Path fichero, String palabra) {

        try {
            //No es necesario cerrar el fichero, porque lo hace solo Java
            //  Abre fichero -> lee todas las lineas -> cierra el fichero
            List<String> lineas = Files.readAllLines(fichero, StandardCharsets.UTF_8);

            int linesFinded = 0;
            for (int i = 0; i < lineas.size(); i++) {

                String linea = lineas.get(i);
                if (linea.toLowerCase().contains(palabra.toLowerCase())) {
                    System.out.printf("%d | %s\n", i + 1, linea);
                    linesFinded++;
                }
            }

            System.out.println("─────────────────────────────");
            System.out.printf("%d coincidencia(s) encontrada(s).\n",linesFinded);

        } catch (IOException e) {
            System.out.println("ERROR: Procesar fichero " + e.getMessage());
        }


        // TODO: Implementar búsqueda case-insensitive
        // TODO: Mostrar líneas coincidentes con su número
    }
}
