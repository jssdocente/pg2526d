package org.example.intermedio;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/**
 * ACTIVIDAD 05: Copias de Seguridad con try-with-resources
 * 
 * ENUNCIADO:
 * Desarrolla la clase GestorBackup con estos métodos:
 * 
 * 1. copiarConTransformacion(Path origen, Path destino, String prefijo) — Copia el fichero 
 *    origen al destino, añadiendo el prefijo al principio de cada línea.
 * 2. anonimizar(Path entrada, Path salida) — Lee un CSV con estructura nombre,telefono,email,nota 
 *    y escribe un nuevo CSV donde el teléfono está enmascarado (XXX-XXX-XXX) 
 *    y el email muestra solo el dominio (***@gmail.com).
 * 3. contarLineasYPalabras(Path fichero) — Devuelve un int[] con {numLineas, numPalabras}.
 * 
 * Requisitos:
 * 1. Todos los métodos deben usar try-with-resources.
 * 2. En copiarConTransformacion, ambos recursos (lector y escritor) se declaran en el mismo try.
 * 3. En anonimizar, la máscara del email conserva el dominio.
 * 4. Las líneas vacías o comentarios (#) se copian sin transformar.
 */
public class GestorBackup {

    public static void main(String[] args) {

        GestorBackup.copiarConTransformacion(
                Paths.get("data","poema.txt"),
                Paths.get("data","poema_prefijo.txt"),
                "MARIA_"
        );

        GestorBackup.anonimizar(
                Paths.get("data","alumnos.csv"),
                Paths.get("data","alumnos_anon.csv")
        );

        int[] result =  GestorBackup.contarLineasYPalabras(
                Paths.get("data","alumnos.csv")
        );

    }

    public static void copiarConTransformacion(Path origen, Path destino, String prefijo) {

        try (
                BufferedReader reader = Files.newBufferedReader(origen);
                BufferedWriter writer = Files.newBufferedWriter(destino,
                        StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE,
                        StandardOpenOption.TRUNCATE_EXISTING)
        ) {
            //Comenzamos la lectura de las líneas
            String linea;
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
                String lineaModificada = prefijo + linea;

                writer.write(lineaModificada);
                writer.newLine();
            }

        } catch (IOException ex) {
            System.out.println("ERROR copiarConTransformación.\n" + ex.getMessage());
        }
    }

    public static void anonimizar(Path entrada, Path salida) {

        try (
                BufferedReader reader = Files.newBufferedReader(entrada);
                BufferedWriter writer = Files.newBufferedWriter(salida,
                        StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.TRUNCATE_EXISTING)
                ) {

             String linea;
             int numLinea = 0;
             while ((linea = reader.readLine())!=null) {

                 numLinea++;

                 if (numLinea==1) {
                     //Saltamos la primera línea, cabecera
                     writer.write(linea);
                     writer.newLine();
                     continue;
                 }

                 //Procesar la línea
                 String[] campos = linea.split(",");

                 String telefono = campos[1];
                 telefono = "XXX-XXX-XXX";

                 String email = campos[2];

                 if (email.indexOf('@')>=0) {
                     email = "***" + email.substring(email.indexOf('@'));
                 }

                 //Nueva linea
                 //String nuevaLinea = campos[0] + "," + telefono + "," + email + "," + campos[3];

                 StringBuilder builder = new StringBuilder();
                 builder.append(campos[0]);builder.append(",");
                 builder.append(telefono);builder.append(",");
                 builder.append(email);builder.append(",");
                 builder.append(campos[3]);

                 //Escribir la nueva línea
                 writer.write(builder.toString());
                 writer.newLine();
             }

        } catch (IOException ex) {
            System.out.println("ERROR anonimizar.\n" + ex.getMessage());
        }

    }

    public static int[] contarLineasYPalabras(Path fichero) {

        int totalLineas=0,totalPalabras = 1;

        try (
                BufferedReader reader = Files.newBufferedReader(fichero)
        ) {

            String linea;
            while ((linea = reader.readLine())!=null) {

                totalLineas++;

                if (totalLineas==1) {
                    //Saltamos la primera línea, cabecera
                    continue;
                }

                //Contar palabras
                String[] campos = linea.split("\\s+");
                totalPalabras = totalLineas + campos.length;

            }

        } catch (IOException ex) {
            System.out.println("ERROR anonimizar.\n" + ex.getMessage());
        }

        return new int[]{totalLineas, totalPalabras};
    }
}
