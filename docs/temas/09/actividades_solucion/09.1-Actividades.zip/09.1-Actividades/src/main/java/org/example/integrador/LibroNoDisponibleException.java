package org.example.integrador;

public class LibroNoDisponibleException extends Exception {
    public LibroNoDisponibleException(String message) {
        super(message);
    }
}
