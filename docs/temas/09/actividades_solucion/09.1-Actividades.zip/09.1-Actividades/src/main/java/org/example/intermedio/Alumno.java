package org.example.intermedio;

import java.util.Locale;

public record Alumno(String nombre, double t1, double t2, double t3) {
    public double media() {
        if (t1 == -1 || t2 == -1 || t3 == -1) {
            return -1;
        }
        return (t1 + t2 + t3) / 3.0;
    }

    public String estado() {
        double m = media();
        if (m == -1) return "PENDIENTE";
        return m >= 5 ? "APROBADO" : "SUSPENSO";
    }

    public String formatNota(double nota) {
        return nota == -1 ? "---" : String.format("%.1f", nota);
    }
}
