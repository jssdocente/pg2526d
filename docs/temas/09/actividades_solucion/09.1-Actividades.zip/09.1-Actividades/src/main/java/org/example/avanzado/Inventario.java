package org.example.avanzado;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * ACTIVIDAD 09: Serialización: Gestor de Inventario
 * 
 * ENUNCIADO:
 * Desarrolla un sistema de inventario para una tienda de tecnología:
 * 
 * 1. Clase Producto (id, nombre, precio, stock, categoria) que implemente Serializable.
 * 2. guardar(List<Producto> productos, Path fichero) — Serializa la lista completa.
 * 3. cargar(Path fichero) — Deserializa y devuelve la lista (o lista vacía si no existe).
 * 4. buscarPorCategoria(List<Producto> productos, String categoria) — Filtrado de lista.
 * 5. actualizarStock(List<Producto> productos, int id, int nuevoStock) — Modifica el stock 
 *    del producto por ID.
 * 
 * Requisitos:
 * 1. Producto debe declarar serialVersionUID = 1L.
 * 2. usar try-with-resources en cargar/guardar.
 * 3. Demostrar el ciclo completo en el main: crear -> guardar -> cargar -> modificar -> guardar.
 */
public class Inventario {

    private static Path rutaApp = Paths.get("data","inventario");

    public static void main(String[] args) {
        List<Producto> productos = new ArrayList<>();

        productos.add(new Producto(1, "Raton", 10.0, 5, "Periferico"));
        productos.add(new Producto(2, "Pantalla", 100.0, 5, "Periferico"));
        productos.add(new Producto(3, "Teclado", 50.0, 5, "Periferico"));
        productos.add(new Producto(4, "Ventilador", 50.0, 5, "Componente"));
        productos.add(new Producto(5, "Procesador", 50.0, 5, "Componente"));

        Inventario gestor = new Inventario();

        Map<String,List<Producto>> categorias = gestor.agruparPorCategoria(productos);

        Path fichero = Paths.get("inventario.dat");
        //gestor.guardar(productos,fichero);
        List<Producto> productosRecuperados = gestor.cargar(fichero);

    }

    public Map<String, List<Producto>> agruparPorCategoria(List<Producto> productos) {

        return productos.stream()
                .collect(Collectors.groupingBy(p-> p.getCategoria()));

    }

    public void guardar(List<Producto> productos, Path fichero) {

        Path rutaFichero = rutaApp.resolve(fichero);
        try {
            Files.createDirectories(rutaApp);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        try(ObjectOutputStream oos = new ObjectOutputStream(Files.newOutputStream(rutaFichero))) {

            oos.writeObject(productos);

            System.out.println("Productos guardados correctamente en " + rutaFichero);

        } catch (IOException e) {
            System.out.println("ERROR guardar.\n" + e.getMessage());
        } catch (Exception ex) {
            System.out.println("ERROR guardarrr.\n" + ex.getMessage());
        }



    }

    public List<Producto> cargar(Path fichero) {
        // TODO: Usar ObjectInputStream para deserializar

        Path rutaFichero = rutaApp.resolve(fichero);

        if (!Files.exists(rutaFichero)) {
            System.out.printf("Cargar productos. El fichero %s no existe\n",fichero);
            return new ArrayList<Producto>();
        }

        System.out.println("esto es una prueba");

        try(ObjectInputStream ois = new ObjectInputStream(Files.newInputStream(rutaFichero))) {

            List<Producto> productos = (List<Producto>) ois.readObject();
            return productos;

        } catch (ClassNotFoundException cex) {
            System.out.println("ERROR recuperar productos.\n" + cex.getMessage());
        } catch (IOException e) {
            System.out.println("ERROR recuperar productos.\n" + e.getMessage());
        } catch (Exception ex) {
            System.out.println("ERROR recuperar productos.\n" + ex.getMessage());
        }

        return new ArrayList<Producto>();
    }

    public List<Producto> buscarPorCategoria(List<Producto> productos, String categoria) {

        //Declarativa
        return productos.stream()
                .filter(p-> p.getCategoria().equalsIgnoreCase(categoria))
                .toList();

        //Imperativa
        /*List<Producto> resultado = new ArrayList<>();

        for (Producto p: productos) {
            if (p.getCategoria().equalsIgnoreCase(categoria)) {
                resultado.add(p);
            }
        }

        return resultado;*/
    }

    public boolean actualizarStock(List<Producto> productos, int id, int nuevoStock) {

        //Version Declarativa
      boolean result = productos.stream()
                .filter(p-> p.getId()==id)
               .findFirst()
               .map(p -> {
                    p.setStock(nuevoStock);
                    return true;
                }).orElse(false);


       //Imperativa
        for (Producto p: productos) {
            if (p.getId()==id) {
                p.setStock(nuevoStock);
                return true;
            }
        }

        return false;


//        if (result.isPresent()) {
//            result.get().setStock(nuevoStock);
//            return true;
//        }
//
//        return false;


    }
}
