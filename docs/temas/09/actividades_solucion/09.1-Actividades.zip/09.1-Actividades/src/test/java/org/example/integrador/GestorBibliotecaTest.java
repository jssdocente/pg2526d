package org.example.integrador;

import org.junit.jupiter.api.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

public class GestorBibliotecaTest {
    private GestorBiblioteca gestor;
    private static final Path BASE_PATH = Paths.get("biblioteca");

    @BeforeEach
    void setUp() throws IOException {
        borrarDirectorio(BASE_PATH);
        gestor = new GestorBiblioteca();
    }

    private void borrarDirectorio(Path path) throws IOException {
        if (Files.exists(path)) {
            try (var stream = Files.walk(path)) {
                stream.sorted(Comparator.reverseOrder())
                      .forEach(p -> {
                          try {
                              Files.delete(p);
                          } catch (IOException e) {
                              // Ignorar
                          }
                      });
            }
        }
    }

    @Test
    void testInicializacion() {
        assertTrue(Files.exists(BASE_PATH.resolve("datos")));
        assertTrue(Files.exists(BASE_PATH.resolve("logs")));
        assertTrue(Files.exists(BASE_PATH.resolve("exportaciones")));
        assertTrue(Files.exists(BASE_PATH.resolve("logs/actividad.log")));
    }

    @Test
    void testImportarExportarCatalogo() {
        List<Libro> libros = List.of(
            new Libro("1", "T1", "A1", 2000, true),
            new Libro("2", "T2", "A2", 2010, false)
        );
        gestor.exportarCatalogo(libros);
        
        List<Libro> importados = gestor.importarCatalogo();
        assertEquals(2, importados.size());
        assertEquals("T1", importados.get(0).titulo());
        assertTrue(importados.get(0).disponible());
        assertFalse(importados.get(1).disponible());
    }

    @Test
    void testPrestamosYSerializacion() throws LibroNoDisponibleException {
        Libro l1 = new Libro("1", "T1", "A1", 2000, true);
        List<Prestamo> prestamos = new ArrayList<>();
        
        gestor.realizarPrestamo(l1, "Pepe", prestamos);
        assertEquals(1, prestamos.size());
        assertEquals("Pepe", prestamos.get(0).nombreSocio());
        
        gestor.guardarPrestamos(prestamos);
        List<Prestamo> cargados = gestor.cargarPrestamos();
        
        assertEquals(1, cargados.size());
        assertEquals("Pepe", cargados.get(0).nombreSocio());
    }

    @Test
    void testExcepcionLibroNoDisponible() {
        Libro l1 = new Libro("1", "T1", "A1", 2000, false);
        List<Prestamo> prestamos = new ArrayList<>();
        
        assertThrows(LibroNoDisponibleException.class, () -> {
            gestor.realizarPrestamo(l1, "Pepe", prestamos);
        });
    }

    @Test
    void testEstadisticas() throws LibroNoDisponibleException {
        Libro l1 = new Libro("1", "T1", "A1", 2000, true);
        Libro l2 = new Libro("2", "T2", "A2", 2010, true);
        List<Libro> catalogo = List.of(l1, l2);
        List<Prestamo> prestamos = new ArrayList<>();
        
        gestor.realizarPrestamo(l1, "Pepe", prestamos);
        gestor.realizarPrestamo(l2, "Pepe", prestamos);
        gestor.realizarPrestamo(l1, "Maria", prestamos);
        
        Map<String, Long> porSocio = gestor.estadisticasPrestamosPorSocio(prestamos);
        assertEquals(2, porSocio.get("Pepe"));
        assertEquals(1, porSocio.get("Maria"));
        
        List<String> masPrestados = gestor.librosMasPrestados(prestamos, catalogo);
        assertEquals("T1", masPrestados.get(0));
    }
}
