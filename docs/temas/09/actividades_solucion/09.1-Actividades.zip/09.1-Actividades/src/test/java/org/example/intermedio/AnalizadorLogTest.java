package org.example.intermedio;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

public class AnalizadorLogTest {

    @TempDir
    Path tempDir;

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @BeforeEach
    void setUpStream() {
        System.setOut(new PrintStream(outContent));
    }

    @AfterEach
    void restoreStream() {
        System.setOut(originalOut);
    }

    @Test
    void testContarPorNivel() throws Exception {
        Path log = tempDir.resolve("servidor.log");
        Files.write(log, List.of(
            "[2026-03-15 08:00:01] [INFO ] [AUTH] 1",
            "[2026-03-15 08:01:00] [INFO ] [DB] 2",
            "[2026-03-15 08:02:00] [ERROR] [NET] 3",
            "[2026-03-15 08:03:00] [WARN ] [AUTH] 4"
        ));

        AnalizadorLog analizador = new AnalizadorLog();
        analizador.contarPorNivel(log);

        String output = outContent.toString();
        assertTrue(output.contains("INFO: 2"));
        assertTrue(output.contains("ERROR: 1"));
        assertTrue(output.contains("WARN: 1"));
    }

    @Test
    void testFiltrarErrores() throws Exception {
        Path log = tempDir.resolve("servidor.log");
        Files.write(log, List.of(
            "[2026-03-15 08:00:01] [INFO ] [AUTH] Servidor OK",
            "[2026-03-15 08:07:44] [ERROR] [DB] Timeout",
            "[2026-03-15 08:12:20] [WARN ] [AUTH] Acceso fallido"
        ));

        AnalizadorLog analizador = new AnalizadorLog();
        List<String> errores = analizador.obtenerErrores(log);

        assertNotNull(errores);
        assertEquals(1, errores.size());
        assertTrue(errores.get(0).contains("Timeout"));
    }

    @Test
    void testModulosAfectados() throws Exception {
        Path log = tempDir.resolve("servidor.log");
        Files.write(log, List.of(
            "[2026-03-15 08:00:01] [ERROR] [DB] Error 1",
            "[2026-03-15 08:01:00] [ERROR] [AUTH] Error 2",
            "[2026-03-15 08:02:00] [ERROR] [DB] Error 3",
            "[2026-03-15 08:03:00] [INFO ] [NET] Info 1"
        ));

        AnalizadorLog analizador = new AnalizadorLog();
        List<String> modulos = analizador.modulosAfectados(log);

        assertEquals(2, modulos.size());
        assertEquals("AUTH", modulos.get(0));
        assertEquals("DB", modulos.get(1));
    }

    @Test
    void testPrimerasEntradas() throws Exception {
        Path log = tempDir.resolve("servidor.log");
        Files.write(log, List.of(
            "[2026-03-15 08:00:01] [INFO ] [AUTH] 1",
            "[2026-03-15 08:01:00] [WARN ] [DB] 2",
            "[2026-03-15 08:02:00] [ERROR] [NET] 3",
            "[2026-03-15 08:03:00] [INFO ] [AUTH] 4",
            "[2026-03-15 08:04:00] [ERROR] [DB] 5"
        ));

        AnalizadorLog analizador = new AnalizadorLog();
        List<String> primeras = analizador.primerasEntradas(log, 2);

        assertEquals(2, primeras.size());
        assertTrue(primeras.get(0).contains("[WARN ]"));
        assertTrue(primeras.get(1).contains("[ERROR]"));
        assertFalse(primeras.stream().anyMatch(l -> l.contains("[INFO ]")));
    }

    @Test
    void testTieneErroresCriticos() throws Exception {
        Path log = tempDir.resolve("servidor.log");
        Files.write(log, List.of(
            "[2026-03-15 08:00:01] [ERROR] [DB] Fatal error",
            "[2026-03-15 08:01:00] [INFO ] [AUTH] System OK"
        ));

        AnalizadorLog analizador = new AnalizadorLog();
        assertTrue(analizador.tieneErroresCriticos(log, "Fatal"));
        assertFalse(analizador.tieneErroresCriticos(log, "System"));
    }
}
