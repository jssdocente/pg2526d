package com.pg.ligabasket;

import com.pg.ligabasket.cifrado.CifradoCesar;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class FicheroLiga {

    private static final String FICHERO_CIFRADO       = "data/partidos_cifrado.txt";
    private static final String FICHERO_CLASIFICACION = "data/clasificacion.txt";
    private static final int    DESPLAZAMIENTO        = 2;

    private static final CifradoCesar cifrador = new CifradoCesar();

    /**
     * TODO F2 (5 puntos): Lee el fichero cifrado, lo descifra y devuelve los partidos.
     *
     * Pasos:
     *   1. Leer el contenido completo de FICHERO_CIFRADO
     *      (puedes usar Files.readString(Path.of(...)))
     *   2. Llamar a cifrador.descifrar() con DESPLAZAMIENTO para obtener el CSV
     *   3. Parsear el CSV línea a línea y construir cada Partido
     *
     * Formato CSV descifrado (una línea por partido):
     *   jornada;equipoLocal;equipoVisitante;puntosLocal;puntosVisitante
     *
     * @return List<Partido> con todos los partidos cargados
     * @throws IOException si hay error al leer el fichero
     */
    public List<Partido> cargarPartidos() throws IOException {
        // TODO: implementar
        throw new UnsupportedOperationException("TODO: implementar cargarPartidos()");
    }

    /**
     * TODO F3 (2 puntos): Guarda la clasificación en FICHERO_CLASIFICACION.
     *
     * Una línea por equipo, sin formato especial. Usa FilaClasificacion.toString()
     * que ya devuelve el formato correcto:
     *   nombre;puntos;puntosAFavor;puntosEnContra;victorias;derrotas
     *
     * Ejemplo del fichero resultante:
     *   CELTICS;6;302;276;3;0
     *   LAKERS;4;313;304;2;1
     *   BULLS;2;279;292;1;2
     *   WARRIORS;0;292;314;0;3
     *
     * @param clasificacion lista ordenada de FilaClasificacion a guardar
     * @throws IOException si hay error al escribir el fichero
     */
    public void guardarClasificacion(List<FilaClasificacion> clasificacion) throws IOException {
        // TODO: implementar
        throw new UnsupportedOperationException("TODO: implementar guardarClasificacion()");
    }
}
