package com.pg.ligabasket;

import java.util.List;
import java.util.Map;

public class LigaService {

    /**
     * TODO C1 (2 puntos): Calcula la clasificación a partir de los partidos.
     *
     * Para cada partido, actualiza la FilaClasificacion del equipo local y visitante
     * usando actualizarStats(misPuntos, susPuntos).
     * Implementación libre (imperativa o con Streams).
     *
     * @param partidos lista de partidos jugados
     * @return lista de FilaClasificacion (una por equipo, sin ordenar)
     */
    public List<FilaClasificacion> calcularClasificacion(List<Partido> partidos) {
        // TODO: implementar
        throw new UnsupportedOperationException("TODO: implementar calcularClasificacion()");
    }

    /**
     * TODO C2 (3 puntos) — OBLIGATORIO CON STREAMS Y Comparator.
     *
     * Ordena la clasificación con este criterio:
     *   1º Puntos de clasificación descendente  (victorias * 2)
     *   2º Diferencia de puntos anotados descendente
     *   3º Nombre del equipo ascendente (alfabético)
     *
     * @param clasificacion lista de FilaClasificacion sin ordenar
     * @return nueva lista ordenada (no modifica la lista original)
     */
    public List<FilaClasificacion> ordenarClasificacion(List<FilaClasificacion> clasificacion) {
        // TODO: OBLIGATORIO implementar con Streams
        throw new UnsupportedOperationException("TODO: implementar ordenarClasificacion() con Streams");
    }

    /**
     * TODO C3 (2 puntos) — OBLIGATORIO CON STREAMS.
     *
     * Devuelve los equipos con cero derrotas (invictos).
     *
     * @param clasificacion lista de FilaClasificacion
     * @return lista de Equipo con derrotas == 0
     */
    public List<Equipo> filtrarInvictos(List<FilaClasificacion> clasificacion) {
        // TODO: OBLIGATORIO implementar con Streams
        throw new UnsupportedOperationException("TODO: implementar filtrarInvictos() con Streams");
    }

    /**
     * TODO C4 (1.5 puntos) — OBLIGATORIO CON Stream.max().
     *
     * Devuelve el equipo con más puntos anotados (puntosAFavor).
     * Si la lista está vacía, devuelve null.
     *
     * @param clasificacion lista de FilaClasificacion
     * @return Equipo con mayor puntosAFavor
     */
    public Equipo obtenerMaximoAnotador(List<FilaClasificacion> clasificacion) {
        // TODO: OBLIGATORIO implementar con Stream.max()
        throw new UnsupportedOperationException("TODO: implementar obtenerMaximoAnotador() con Stream.max()");
    }

    /**
     * TODO C5 (1.5 puntos) — OBLIGATORIO CON Collectors.groupingBy().
     *
     * Agrupa los nombres de equipo por su número de victorias.
     *
     * Ejemplo de salida esperada:
     *   {0=[WARRIORS], 1=[BULLS], 2=[LAKERS], 3=[CELTICS]}
     *
     * @param clasificacion lista de FilaClasificacion
     * @return Map donde clave=victorias, valor=lista de nombres de equipo
     */
    public Map<Integer, List<String>> agruparPorVictorias(List<FilaClasificacion> clasificacion) {
        // TODO: OBLIGATORIO implementar con Collectors.groupingBy()
        throw new UnsupportedOperationException("TODO: implementar agruparPorVictorias() con groupingBy()");
    }
}
