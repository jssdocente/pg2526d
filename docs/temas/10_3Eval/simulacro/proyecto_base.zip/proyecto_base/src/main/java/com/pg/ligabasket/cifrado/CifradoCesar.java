package com.pg.ligabasket.cifrado;

public class CifradoCesar {

    /**
     * TODO F1 (3 puntos): Descifra el texto usando el algoritmo César.
     *
     * Reglas:
     *   - Solo se descifran las LETRAS (mayúsculas y minúsculas).
     *   - Los números, punto y coma, saltos de línea, etc., se copian sin modificar.
     *   - Descifrar = restar el desplazamiento con vuelta circular dentro del alfabeto.
     *
     * Ejemplos con desplazamiento 2:
     *   'N' -> 'L'   (N=14, 14-2=12=L)
     *   'C' -> 'A'   (C=3,  3-2=1=A)
     *   'B' -> 'Z'   (B=2,  2-2=0 -> vuelta: Z)
     *   'A' -> 'Y'   (A=1,  1-2=-1 -> vuelta: Y)
     *
     * @param textoCifrado   texto completo leído del fichero cifrado
     * @param desplazamiento número de posiciones del cifrado original (para descifrar, se resta)
     * @return String con el texto descifrado
     */
    public String descifrar(String textoCifrado, int desplazamiento) {
        // TODO: implementar
        throw new UnsupportedOperationException("TODO: implementar descifrar()");
    }
}
