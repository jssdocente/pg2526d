package com.pg.ligabasket;

public class FilaClasificacion {

    private final Equipo equipo;
    private int puntos;          // victorias * 2
    private int puntosAFavor;
    private int puntosEnContra;
    private int victorias;
    private int derrotas;

    public FilaClasificacion(Equipo equipo) {
        this.equipo = equipo;
    }

    public void actualizarStats(int misPuntos, int susPuntos) {
        puntosAFavor += misPuntos;
        puntosEnContra += susPuntos;
        if (misPuntos > susPuntos) {
            victorias++;
            puntos += 2;
        } else {
            derrotas++;
        }
    }

    public Equipo getEquipo()            { return equipo; }
    public int getPuntos()               { return puntos; }
    public int getPuntosAFavor()         { return puntosAFavor; }
    public int getPuntosEnContra()       { return puntosEnContra; }
    public int getVictorias()            { return victorias; }
    public int getDerrotas()             { return derrotas; }
    public int getDiferenciaPuntos()     { return puntosAFavor - puntosEnContra; }

    @Override
    public String toString() {
        return equipo.getNombre() + ";" + puntos + ";" + puntosAFavor + ";"
                + puntosEnContra + ";" + victorias + ";" + derrotas;
    }
}
