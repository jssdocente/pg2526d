package com.pg.ligabasket;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class App {

    public static void main(String[] args) throws IOException {

        FicheroLiga ficheroLiga = new FicheroLiga();
        LigaService ligaService = new LigaService();

        System.out.println("=== LIGA DE BALONCESTO - TEMPORADA 25/26 ===\n");

        // F2: Cargar partidos desde el fichero cifrado
        System.out.println("--- Partidos cargados ---");
        List<Partido> partidos = ficheroLiga.cargarPartidos();
        System.out.println("Total partidos: " + partidos.size());
        partidos.forEach(System.out::println);

        // C1: Calcular clasificación
        List<FilaClasificacion> clasificacion = ligaService.calcularClasificacion(partidos);

        // C2: Ordenar clasificación
        System.out.println("\n--- Clasificación ---");
        List<FilaClasificacion> ordenada = ligaService.ordenarClasificacion(clasificacion);
        System.out.printf("%-2s %-15s %5s %7s %7s %5s%n", "Pos", "Equipo", "Pts", "PAF", "PAC", "Dif");
        System.out.println("-".repeat(45));
        for (int i = 0; i < ordenada.size(); i++) {
            FilaClasificacion f = ordenada.get(i);
            System.out.printf("%-2d %-15s %5d %7d %7d %+5d%n",
                    i + 1, f.getEquipo().getNombre(), f.getPuntos(),
                    f.getPuntosAFavor(), f.getPuntosEnContra(), f.getDiferenciaPuntos());
        }

        // C3: Equipos invictos
        System.out.println("\n--- Equipos invictos ---");
        List<Equipo> invictos = ligaService.filtrarInvictos(clasificacion);
        if (invictos.isEmpty()) System.out.println("Ningún equipo invicto.");
        else invictos.forEach(e -> System.out.println("- " + e.getNombre()));

        // C4: Máximo anotador
        System.out.println("\n--- Máximo anotador ---");
        Equipo maxAnotador = ligaService.obtenerMaximoAnotador(clasificacion);
        System.out.println(maxAnotador != null
                ? "Equipo: " + maxAnotador.getNombre()
                : "Sin datos.");

        // C5: Agrupación por victorias
        System.out.println("\n--- Equipos por victorias ---");
        Map<Integer, List<String>> porVictorias = ligaService.agruparPorVictorias(clasificacion);
        porVictorias.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(e -> System.out.println(e.getKey() + " victoria(s): " + e.getValue()));

        // F3: Guardar clasificación
        System.out.println("\n--- Guardando clasificación ---");
        ficheroLiga.guardarClasificacion(ordenada);
        System.out.println("Fichero guardado: data/clasificacion.txt");
    }
}
