package com.pg.ligabasket;

public class Partido {

    private final int jornada;
    private final Equipo equipoLocal;
    private final Equipo equipoVisitante;
    private final int puntosLocal;
    private final int puntosVisitante;

    public Partido(int jornada, Equipo equipoLocal, Equipo equipoVisitante,
                   int puntosLocal, int puntosVisitante) {
        this.jornada = jornada;
        this.equipoLocal = equipoLocal;
        this.equipoVisitante = equipoVisitante;
        this.puntosLocal = puntosLocal;
        this.puntosVisitante = puntosVisitante;
    }

    public int getJornada()              { return jornada; }
    public Equipo getEquipoLocal()       { return equipoLocal; }
    public Equipo getEquipoVisitante()   { return equipoVisitante; }
    public int getPuntosLocal()          { return puntosLocal; }
    public int getPuntosVisitante()      { return puntosVisitante; }

    @Override
    public String toString() {
        return "[J" + jornada + "] " + equipoLocal.getNombre()
                + " " + puntosLocal + " - " + puntosVisitante
                + " " + equipoVisitante.getNombre();
    }
}
