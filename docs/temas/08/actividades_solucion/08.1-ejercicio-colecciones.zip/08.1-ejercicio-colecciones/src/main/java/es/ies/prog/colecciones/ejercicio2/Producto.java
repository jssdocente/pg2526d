package es.ies.prog.colecciones.ejercicio2;

/*
 * EJERCICIO 2: Producto
 * 
 * Clase modelo que representa un producto del inventario.
 * 
 * Requisitos:
 * - Atributos id (int), nombre (String), stock (int).
 * - Constructor que reciba todos los campos.
 * - Getters (getId, getNombre, getStock).
 * - Setter (setStock).
 */

import java.util.Objects;

public class Producto implements Comparable<Producto> {

    private int id;
    private String nombre;
    private int stock;

    public Producto(int id, String nombre, int stock) {
        this.id = id;
        this.nombre = nombre;
        this.stock = stock;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Producto producto)) return false;
        return id == producto.id;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public int compareTo(Producto o) {
       if (o==null)
           return 0;

       if (this.stock==o.stock)
           return 0;

       if (this.stock>o.stock)
           return 1;
       else
           return -1;

    }
}