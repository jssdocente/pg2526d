/*
package es.ies.prog.colecciones.ejercicio_funcional;

import java.util.ArrayList;
import java.util.List;

public class GestorCanciones {

    private ArrayList<Cancion> biblioteca = new ArrayList<>();

    public List<Cancion> getFavoritas() {
        List<Cancion> favoritas = new ArrayList<>();
        for (Cancion c : biblioteca) {
            if (c.esFavorita()) {
                favoritas.add(c);
            }
        }

        return favoritas;
    }

    public List<Cancion> getFavoritasDeclarativa() {

        return biblioteca.stream()
                .filter(song -> song.esFavorita())
                .toList();

    }

    public List<String> getArtistasNombres() {

        return biblioteca.stream()
                .map(song -> song.artista())
                .distinct()
                .toList();

        */
/*Set<String> artistasSet = new HashSet<>();
        for (Cancion c : biblioteca) {
            artistasSet.add(c.artista());
        }
        List<String> artistas = new ArrayList<>(artistasSet)*//*

    }

    public List<String> getCancionesByArtist(String nombreArtista, int duracion) {

        return biblioteca.stream()
                .filter(song -> song.artista().equals(nombreArtista))
                .filter(song -> song.duracionSegundos()>duracion)
                .map(song -> song.titulo())
                .toList();


      */
/*  for (Cancion c : biblioteca) {
            if (c.artista().equals("Quevedo") && c.duracionSegundos() > 180) {
                titulos.add(c.titulo());
            }
        }*//*

    }

    public int suma(int a, int b) {
        return a + b;
    }

    public void reduce(List<int> lista) {
        int acc=0;
        for (int valor: lista) {
            acc=acc+valor;
            acc = suma(acc,valor);
        }
    }

    public int getAlbumDuracionTotal(String album) {

        int total = biblioteca.stream()
                .filter((song) -> song.album().equals(album))
                .mapToInt(song -> song.duracionSegundos())
                .sum();

        biblioteca.stream()
                .filter(song -> song.album().equals(album))
                .map(song -> song.duracionSegundos())
                .reduce(0, (a,b) -> a-b);




        */
/*int totalSegundos = 0;
        for (Cancion c : biblioteca) {
            totalSegundos += c.duracionSegundos();
        }*//*


    }



}
*/
