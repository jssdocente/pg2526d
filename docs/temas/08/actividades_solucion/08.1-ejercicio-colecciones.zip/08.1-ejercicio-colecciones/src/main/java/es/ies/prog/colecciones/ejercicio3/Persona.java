package es.ies.prog.colecciones.ejercicio3;

import java.util.Objects;

public class Persona {
    private String nombre;
    private String dni;

    public Persona(String nombre,String dni) {
        this.nombre=nombre;
        this.dni=dni;
    }

    public String getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Persona persona)) return false;
        return Objects.equals(dni, persona.dni);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(dni);
    }
}
