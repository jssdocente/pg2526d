package es.ies.prog.colecciones.ejercicio1;

/*
 * EJERCICIO 1: Gestor de Notas
 * 
 * Esta clase debe permitir gestionar las notas de un alumno utilizando una lista dinámica (ArrayList).
 * 
 * Requisitos:
 * - Un atributo privado para almacenar las notas (double).
 * - Un constructor que inicialice la lista.
 * - Método 'addNota(double)': añade una nota a la lista.
 * - Método 'calcularMedia()': calcula y retorna el promedio de las notas. (Si no hay notas, retorna 0).
 * - Método 'eliminarNotaMasBaja()': busca la nota más pequeña, la elimina de la lista y retorna true.
 * - Método 'totalNotas()': retorna el número de notas en la lista.
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class GestorNotas {

    ArrayList<Double> notas = new ArrayList<Double>();

    public void addNota(double nota) {
        notas.add(nota);
    }

    public void ordenar() {
        Collections.sort(notas);
    }

    public double calcularMedia() {

        if (this.notas.isEmpty())
            return 0;

        double suma=0;

        for (double nota: this.notas) {
            suma+=nota;
        }
        return suma/this.notas.size();
    }

    public void borrar(Double nota) {
        if (this.notas.contains(nota))
            this.notas.remove(nota);
    }

    public boolean eliminarNotaMasBaja() {
        double notaMenor=Double.MAX_VALUE;

        for (double nota: this.notas) {
            if (nota<notaMenor)
                notaMenor=nota;
        }

        this.notas.remove(notaMenor);

        return true;
    }

    public int totalNotas() {
        return notas.size();
    }

}