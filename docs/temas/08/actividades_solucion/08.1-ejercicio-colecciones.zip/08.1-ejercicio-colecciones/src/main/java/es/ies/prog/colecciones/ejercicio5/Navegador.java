package es.ies.prog.colecciones.ejercicio5;

/*
 * EJERCICIO 5: Historial del Navegador
 * º
 * Clase que simula el botón atrás mediante una estructura LIFO utilizando Deque (pila).
 * 
 * Requisitos:
 * - Un atributo privado utilizando Deque<String>.
 * - Método 'navegar(String url)': añade la URL a la cima de la pila.
 * - Método 'retroceder()': elimina la URL de la cima y retorna la cadena eliminada (null si está vacía).
 * - Método 'getHistorial()': retorna una lista con todos los elementos actuales de la pila para su comprobación.
 */

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public class Navegador {

    private ArrayDeque<String> pila = new ArrayDeque<>();

    public void navegar(String url) {
        pila.push(url);
    }

    public String retroceder() {
        if (pila.isEmpty())
            return null;

        return pila.pop();
    }

    public List<String> getHistorial() {
        return new ArrayList<>(pila);
    }
}