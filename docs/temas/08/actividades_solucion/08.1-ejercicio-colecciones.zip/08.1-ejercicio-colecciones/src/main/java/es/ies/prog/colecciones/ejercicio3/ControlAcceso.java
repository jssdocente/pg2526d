package es.ies.prog.colecciones.ejercicio3;

/*
 * EJERCICIO 3: Control de Acceso
 * 
 * Clase que gestiona una lista de asistentes utilizando HashSet para evitar duplicados.
 * 
 * Requisitos:
 * - Un atributo privado para almacenar los nombres de los asistentes.
 * - Método 'registrar(String nombre)': añade el nombre a la colección. El conjunto evitará automáticamente los duplicados.
 * - Método 'totalUnicos()': retorna la cantidad de asistentes únicos.
 * - Método 'estaEnLista(String nombre)': comprueba si un nombre ya está registrado. Retorna un booleano.
 */

import java.util.ArrayList;
import java.util.HashSet;

public class ControlAcceso<T> {

    private HashSet<T> listaAcceso = new HashSet<T>();

    public void registrar(T elemento) {
        listaAcceso.add(elemento);
    }

    public int totalUnicos() {
        return listaAcceso.size();
    }

    public boolean estaEnLista(T elemento) {
        return listaAcceso.contains(elemento);
    }
}
