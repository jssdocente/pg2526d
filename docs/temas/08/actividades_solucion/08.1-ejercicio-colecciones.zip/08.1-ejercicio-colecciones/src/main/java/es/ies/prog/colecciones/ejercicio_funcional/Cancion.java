package es.ies.prog.colecciones.ejercicio_funcional;

public record Cancion(
        String titulo,
        String artista,
        int duracionSegundos,
        String genero,
        boolean esFavorita,
        String album
) {}
