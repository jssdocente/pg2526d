package es.ies.prog.colecciones.ejercicios_ficheros;

import java.io.IOException;
import java.nio.file.*;

public class InicializadorBiblioteca {

    public static void inicializar() {
        Path pathBase  = Paths.get("datos","facturas");
        Path fichCatalog = pathBase.resolve( "catalogo.txt");
        Path fichPrest   = pathBase.resolve("prestamos.txt");

        try {
            Path pathDelete = Paths.get("datos/boletines.txt");
            Files.delete(pathDelete);

            // Crear el directorio si no existe (createDirectories no falla si ya existe)
            if (!Files.exists(pathBase)) {
                Files.createDirectories(pathBase);
                System.out.println("Directorio 'datos' creado correctamente.");
            } else {
                System.out.println("El directorio 'datos' ya existía.");
            }

            // Crear ficheros solo si no existen
            if (!Files.exists(fichCatalog)) {
                Files.createFile(fichCatalog);
                System.out.println("Fichero 'catalogo.txt' creado.");
            }
            if (!Files.exists(fichPrest)) {
                Files.createFile(fichPrest);
                System.out.println("Fichero 'prestamos.txt' creado.");
            }
        //}
        /*catch (NoSuchFileException ex) {
            System.err.println("Error el fichero no existe " + ex.getMessage());*/

        } catch (IOException e) {
            System.err.println("Error al inicializar la aplicación: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        inicializar();
        System.out.println("Aplicación lista.");
    }
}