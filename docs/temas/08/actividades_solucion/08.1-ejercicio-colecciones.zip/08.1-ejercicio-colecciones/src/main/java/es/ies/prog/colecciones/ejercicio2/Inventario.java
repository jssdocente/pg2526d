package es.ies.prog.colecciones.ejercicio2;

/*
 * EJERCICIO 2: Inventario
 * 
 * Clase que gestiona una lista de productos utilizando ArrayList.
 * 
 * Requisitos:
 * - Un atributo privado para almacenar los productos.
 * - Método 'agregar(Producto p)': añade un producto.
 * - Método 'buscarPorId(int id)': retorna el producto con ese ID o null.
 * - Método 'actualizarStock(String nombre, int stock)': busca el producto por nombre y cambia su stock. Retorna true si lo encontró.
 * - Método 'eliminar(int id)': elimina el producto de la lista basándose en su ID.
 * - Método 'totalProductos()': retorna cuántos productos hay en la lista del inventario.
 */

import java.util.ArrayList;
import java.util.Collections;

public class Inventario {

    private ArrayList<Producto> lista = new ArrayList<>();

    public void agregar(Producto p) {
        this.lista.add(p);
    }

    public void borrarProducto(Producto p) {
        lista.remove(p);
    }

    public Producto buscarPorId(int id) {

        for (Producto p: this.lista) {
            if (p.getId()==id){
                return p;
            }
        }

        return null;
    }

    public Producto buscarPorProducto(Producto p) {

        int index = this.lista.indexOf(p);
        if (index<0)
            return null;

        return this.lista.get(index);
    }

    public boolean actualizarStock(String nombre,int stock) {

        for (Producto p: this.lista) {
            if (p.getNombre().equalsIgnoreCase(nombre)){
                p.setStock(stock);
                return true;
            }
        }

        return false;

    }

    public boolean eliminar(int id) {

        int vecesEliminado=0;
        while (true) {
            boolean eliminado  = this.lista.remove(new Producto(id,"",0));
            if (eliminado)
                vecesEliminado++;

            if (!eliminado)
                break;
        }

        return vecesEliminado > 0;

    }

    public ArrayList<Producto> ordenar() {
        Collections.sort(lista);

        return lista;
    }

    public int totalProductos() {
        return this.lista.size();
    }

}