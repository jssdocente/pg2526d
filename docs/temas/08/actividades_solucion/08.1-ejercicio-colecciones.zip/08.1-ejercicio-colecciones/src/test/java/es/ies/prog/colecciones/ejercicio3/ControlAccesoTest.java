package es.ies.prog.colecciones.ejercicio3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ControlAccesoTest {

    @Test
    public void testRegistrarYTotal() {
        // Arrange
        ControlAcceso<String> control = new ControlAcceso<>();
        
        // Act
        control.registrar("Ana");
        control.registrar("Juan");
        control.registrar("Ana"); // Duplicado no debería contar
        
        // Assert
        assertEquals(2, control.totalUnicos(), "Debería haber solo 2 personas únicas");
    }

    @Test
    public void testEstaEnLista() {
        // Arrange
        ControlAcceso<String> control = new ControlAcceso<>();
        control.registrar("Pedro");
        
        // Act
        boolean estaPresente = control.estaEnLista("Pedro");
        boolean noEstaPresente = control.estaEnLista("Maria");
        
        // Assert
        assertTrue(estaPresente, "Debería estar registrado");
        assertFalse(noEstaPresente, "No debería estar registrado");
    }

    @Test
    public void testCaseSensitivity() {
        // Arrange
        ControlAcceso<String> control = new ControlAcceso<>();
        control.registrar("Ana");
        
        // Act
        boolean conMayuscula = control.estaEnLista("Ana");
        boolean conMinuscula = control.estaEnLista("ana");
        
        // Assert
        assertTrue(conMayuscula);
        assertFalse(conMinuscula, "HashSet es sensible a mayúsculas por defecto");
    }
}
