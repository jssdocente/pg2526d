package es.ies.prog.colecciones.ejercicio1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GestorNotasTest {

    @Test
    public void testAddYTotal() {
        // Arrange (Preparar)
        GestorNotas gestor = new GestorNotas();
        
        // Act (Actuar)
        gestor.addNota(8.5);
        gestor.addNota(6.0);
        
        // Assert (Afirmar/Comprobar)
        assertEquals(2, gestor.totalNotas(), "Debería haber 2 notas registradas");
    }

    @Test
    public void testCalcularMedia() {
        // Arrange
        GestorNotas gestor = new GestorNotas();
        gestor.addNota(10.0);
        gestor.addNota(0.0);
        
        // Act
        double media = gestor.calcularMedia();
        
        // Assert
        assertEquals(5.0, media, 0.01, "La media de 10 y 0 debe ser 5");
    }

    @Test
    public void testEliminarMasBaja() {
        // Arrange
        GestorNotas gestor = new GestorNotas();
        gestor.addNota(9.0);
        gestor.addNota(4.0);
        gestor.addNota(7.5);
        
        // Act
        boolean eliminado = gestor.eliminarNotaMasBaja();
        
        // Assert
        assertTrue(eliminado, "Debería retornar true al eliminar");
        assertEquals((9+7.5)/2, gestor.calcularMedia(), "No más baja no eliminada");
        assertEquals(2, gestor.totalNotas(), "Tras borrar la más baja deben quedar 2");
    }

    @Test
    public void testMediaVacia() {
        GestorNotas gestor = new GestorNotas();
        assertEquals(0, gestor.calcularMedia(), "Si no hay notas la media es 0");
    }
}
