package es.ies.prog.colecciones.ejercicio2;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class InventarioTest {

    @Test
    public void testAgregarYBuscar() {
        // Arrange
        Inventario inventory = new Inventario();
        inventory.agregar(new Producto(1, "Raton", 10));
        inventory.agregar(new Producto(2, "Teclado", 5));

        // Act
        Producto raton = inventory.buscarPorId(1);

        // Assert
        assertNotNull(raton, "Debería encontrar el producto por ID 1");
        assertEquals("Raton", raton.getNombre());
    }

    @Test
    public void testActualizarStock() {
        // Arrange
        Inventario inventory = new Inventario();
        inventory.agregar(new Producto(1, "Monitor", 3));


        // Act
        boolean updated = inventory.actualizarStock("Monitor", 10);

        // Assert
        assertTrue(updated, "Debería actualizar stock del Monitor");
        assertEquals(10, inventory.buscarPorId(1).getStock());
    }

    @Test
    public void testEliminar() {
        // Arrange
        Inventario inventory = new Inventario();
        inventory.agregar(new Producto(5, "Webcam", 7));

        // Act
        inventory.eliminar(5);

        // Assert
        assertEquals(0, inventory.totalProductos(), "El inventario debería estar vacío tras eliminar");
        assertNull(inventory.buscarPorId(5));
    }

    @Test
    public void testOrdenar() {
        // Arrange
        Inventario inventory = new Inventario();
        inventory.agregar(new Producto(5, "Webcam", 7));
        inventory.agregar(new Producto(5, "Raton", 3));
        inventory.agregar(new Producto(5, "Monitor", 9));

        // Act
        ArrayList<Producto> listaOrdenada = inventory.ordenar();

        // Assert
        assertEquals(3,listaOrdenada.get(0).getStock());
        assertEquals(7,listaOrdenada.get(1).getStock());
        assertEquals(9,listaOrdenada.get(2).getStock());
    }
}
