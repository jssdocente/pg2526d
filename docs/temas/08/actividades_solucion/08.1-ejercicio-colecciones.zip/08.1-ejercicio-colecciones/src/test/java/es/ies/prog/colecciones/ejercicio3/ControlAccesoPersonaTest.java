package es.ies.prog.colecciones.ejercicio3;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ControlAccesoPersonaTest {

    @Test
    public void testRegistrarYTotal() {
        // Arrange
        ControlAcceso<Persona> control = new ControlAcceso<>();

        // Act
        control.registrar(new Persona( "Ana","1234567"));
        control.registrar(new Persona( "Juan","1234568"));
        control.registrar(new Persona( "Ana2","1234567")); // Duplicado no debería contar
        
        // Assert
        assertEquals(2, control.totalUnicos(), "Debería haber solo 2 personas únicas");
    }

    @Test
    public void testEstaEnLista() {
        // Arrange
        ControlAcceso<Persona> control = new ControlAcceso<>();
        Persona pedro = new Persona("Pedro","1234567");
        Persona maria = new Persona("Maria","1234568");

        control.registrar(pedro);
        
        // Act
        boolean estaPresente = control.estaEnLista(pedro);
        boolean noEstaPresente = control.estaEnLista(maria);
        
        // Assert
        assertTrue(estaPresente, "Debería estar registrado");
        assertFalse(noEstaPresente, "No debería estar registrado");
    }

}
