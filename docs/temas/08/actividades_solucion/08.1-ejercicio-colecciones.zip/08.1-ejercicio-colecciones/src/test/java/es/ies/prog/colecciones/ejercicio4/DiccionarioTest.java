package es.ies.prog.colecciones.ejercicio4;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DiccionarioTest {

    @Test
    public void testGuardarYTraducir() {
        // Arrange
        Diccionario dic = new Diccionario();
        dic.guardarTraduccion("hola", "hello");
        dic.guardarTraduccion("adios", "goodbye");
        
        // Act
        String t1 = dic.traducir("hola");
        String t2 = dic.traducir("adios");
        String t3 = dic.traducir("java");
        
        assertEquals("hello", t1);
        // Assert
        assertEquals("goodbye", t2);
        assertNull(t3, "No disponible debería retornar null");
    }

    @Test
    public void testActualizarTraduccion() {
        // Arrange
        Diccionario dic = new Diccionario();
        dic.guardarTraduccion("mundo", "world");
        
        // Act
        dic.guardarTraduccion("mundo", "worlds"); // Actualizado
        
        // Assert
        assertEquals("worlds", dic.traducir("mundo"), "Se debería poder actualizar la traducción de una palabra");
        assertEquals(1, dic.totalPalabras(), "Tras actualizar, no debería haber duplicados");
    }

    @Test
    public void testMapVacio() {
        Diccionario dic = new Diccionario();
        assertNull(dic.traducir(""));
        assertEquals(0, dic.totalPalabras());
    }
}
