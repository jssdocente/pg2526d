package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class GestorCatalogoTest {

    private GestorCatalogo gestor;
    private List<Videojuego> biblioteca;

    @BeforeEach
    void setUp() {
        biblioteca = List.of(
            new Videojuego("The Witcher 3", "RPG", 29.99, 95, false),
            new Videojuego("League of Legends", "MOBA", 0.0, 75, true),
            new Videojuego("Resident Evil Village", "Terror", 39.99, 85, false),
            new Videojuego("Amnesia", "Terror", 19.99, 82, false),
            new Videojuego("Among Us", "Party", 3.99, 70, true),
            new Videojuego("Dota 2", "MOBA", 0.0, 80, true),
            new Videojuego("Stardew Valley", "Simulación", 13.99, 90, true)
        );
        gestor = new GestorCatalogo(biblioteca);
    }

    @Test
    void testEjercicio1_buscarGratuitos() {
        List<Videojuego> esperados = gestor.buscarGratuitosImperativo();
        List<Videojuego> actuales = gestor.buscarGratuitosFuncional();
        
        assertNotNull(actuales, "Debes implementar el método funcional");
        assertEquals(esperados.size(), actuales.size());
        assertTrue(actuales.stream().allMatch(v -> v.precio() == 0));
    }

    @Test
    void testEjercicio2_obtenerTitulos() {
        List<String> esperados = gestor.obtenerTitulosImperativo();
        List<String> actuales = gestor.obtenerTitulosFuncional();

        assertNotNull(actuales, "Debes implementar el método funcional");
        assertEquals(esperados, actuales);
    }

    @Test
    void testEjercicio3_mejoresJuegosTerror() {
        List<String> esperados = gestor.mejoresJuegosPorGeneroImperativo("Terror");
        List<String> actuales = gestor.mejoresJuegosPorGeneroFuncional("Terror");

        assertNotNull(actuales, "Debes implementar el método funcional");
        assertEquals(2, actuales.size());
        assertEquals("Amnesia", actuales.get(0));
        assertEquals("Resident Evil Village", actuales.get(1));
    }

    @Test
    void testEjercicio4_valoracionMedia() {
        double esperada = gestor.valoracionMediaImperativo();
        double actual = gestor.valoracionMediaFuncional();

        assertEquals(esperada, actual, 0.01);
    }

    @Test
    void testEjercicio5_joyasOcultas() {
        String esperada = gestor.joyasOcultasImperativo();
        String actual = gestor.joyasOcultasFuncional();

        assertNotNull(actual, "Debes implementar el método funcional");
        assertEquals(esperada, actual);
        assertTrue(actual.contains("League of Legends"));
        assertTrue(actual.contains("Dota 2"));
    }
}
