package org.example;

import java.util.*;
import java.util.stream.Collectors;

public class GestorCatalogo {
    private List<Videojuego> catalogo;

    public GestorCatalogo(List<Videojuego> catalogo) {
        this.catalogo = catalogo;
    }

    /**
     * EJERCICIO 1: Buscar juegos gratuitos
     */
    public List<Videojuego> buscarGratuitosImperativo() {
        List<Videojuego> resultados = new ArrayList<>();
        for (Videojuego v : catalogo) {
            if (v.precio() == 0) {
                resultados.add(v);
            }
        }
        return resultados;
    }

    public List<Videojuego> buscarGratuitosFuncional() {
        // TODO: Implementar usando .stream(), .filter() y .toList()
        return null;
    }

    /**
     * EJERCICIO 2: Obtener lista de títulos
     */
    public List<String> obtenerTitulosImperativo() {
        List<String> nombres = new ArrayList<>();
        for (Videojuego v : catalogo) {
            nombres.add(v.titulo());
        }
        return nombres;
    }

    public List<String> obtenerTitulosFuncional() {
        // TODO: Implementar usando .stream(), .map() y .toList()
        return null;
    }

    /**
     * EJERCICIO 3: Buscar mejores juegos de un género determinado
     */
    public List<String> mejoresJuegosPorGeneroImperativo(String genero) {
        List<String> resultados = new ArrayList<>();
        for (Videojuego v : catalogo) {
            if (v.genero().equals(genero) && v.valoracion() > 80) {
                resultados.add(v.titulo());
            }
        }
        Collections.sort(resultados);
        return resultados;
    }

    public List<String> mejoresJuegosPorGeneroFuncional(String genero) {
        // TODO: Implementar usando .stream(), .filter(), .map() y .sorted()
        return null;
    }

    /**
     * EJERCICIO 4: Calcular valoración media
     */
    public double valoracionMediaImperativo() {
        if (catalogo.isEmpty()) return 0;
        double suma = 0;
        for (Videojuego v : catalogo) {
            suma += v.valoracion();
        }
        return suma / catalogo.size();
    }

    public double valoracionMediaFuncional() {
        // TODO: Implementar usando .stream(), .mapToInt() y .average()
        return 0;
    }

    /**
     * EJERCICIO 5: Obtener cadena con los 3 juegos multijugador más baratos
     */
    public String joyasOcultasImperativo() {
        List<Videojuego> multi = new ArrayList<>();
        for (Videojuego v : catalogo) {
            if (v.esMultijugador()) multi.add(v);
        }
        
        // Ordenación Imperativa: Usamos una clase anónima para implementar el "contrato" 
        // de Comparator sin tener que crear un archivo .java aparte (ej. ComparadorPrecio.java).
        // Esto ahorra archivos en el proyecto, pero genera mucho código "boilerplate".
        Collections.sort(multi, new Comparator<Videojuego>() {
            @Override
            public int compare(Videojuego v1, Videojuego v2) {
                return Double.compare(v1.precio(), v2.precio());
            }
        });
        
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(3, multi.size()); i++) {
            sb.append(multi.get(i).titulo());
            if (i < 2 && i < multi.size() - 1) sb.append(" - ");
        }
        return sb.toString();
    }

    public String joyasOcultasFuncional() {
        // TODO: Implementar usando pipeline completo de streams
        return null;
    }
}
