package org.example;

public record Videojuego(
    String titulo, 
    String genero, 
    double precio, 
    int valoracion, 
    boolean esMultijugador
) {}
