package org.example.logistica;

/*
 * EJERCICIO 5: Hoja de Reparto (TreeMap)
 * 
 * Esta clase organiza los paquetes por su código postal de destino.
 * 
 * Requisitos:
 * - Un atributo privado de tipo Map<String, Paquete> que garantice la ordenación por clave.
 * - Método 'registrarEnvio(Paquete)': añade la entrada al mapa usando el CP como clave.
 * - Método 'totalZonas()': retorna cuántas zonas (CPs) diferentes hay en el mapa.
 */
