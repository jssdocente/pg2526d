package org.example.logistica;

/*
 * EJERCICIO 4: Comparador de Urgencia
 * 
 * Clase que implementa la interfaz Comparator para definir un orden alternativo.
 * 
 * Requisitos:
 * - Implementar compare(Paquete, Paquete) para ordenar por nivel de urgencia de forma DESCENDENTE (5 a 1).
 */
