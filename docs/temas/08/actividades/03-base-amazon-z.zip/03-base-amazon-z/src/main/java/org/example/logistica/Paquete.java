package org.example.logistica;

/*
 * ENTIDAD: Paquete
 * 
 * Esta clase representa un paquete en el sistema logístico. 
 * Debe implementar la interfaz Comparable<Paquete>.
 * 
 * Requisitos:
 * - Atributos privados: trackingID (String), peso (double), codigoPostal (String), urgencia (int).
 * - Constructor que inicialice todos los atributos.
 * - Métodos getter para todos los atributos.
 * - Implementación de compareTo(Paquete): Orden natural por peso (menor a mayor).
 */
