package org.example.logistica;

/*
 * EJERCICIO 2: Mesa de Devoluciones (LIFO)
 * 
 * Esta clase gestiona la pila de paquetes que llegan devueltos y se acumulan en una mesa.
 * 
 * Requisitos:
 * - Un atributo privado de tipo Deque<Paquete> o Stack<Paquete>.
 * - Método 'apilarPaquete(Paquete)': añade el paquete a la pila (arriba).
 * - Método 'inspeccionar()': extrae y devuelve el paquete de la cima de la pila (LIFO).
 */
