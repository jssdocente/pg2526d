package org.example.logistica;

/*
 * EJERCICIO 6: Entidad Mantenimiento
 * 
 * Esta clase representa una tarea de mantenimiento programada.
 * Debe implementar la interfaz Comparable<Mantenimiento>.
 * 
 * Requisitos:
 * - Atributos privados: id (String), coste (double), criticidad (int del 1 al 10).
 * - Constructor que inicialice todos los atributos.
 * - Métodos getter para todos los atributos.
 * - Implementación de compareTo(Mantenimiento): Orden natural por CRITICIDAD (de mayor a menor).
 */
