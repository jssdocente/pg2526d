package org.example.logistica;

/*
 * EJERCICIO 3: Almacén (Orden Natural)
 * 
 * Esta clase se encarga de organizar el inventario del almacén.
 * 
 * Requisitos:
 * - Método 'ordenarPorPeso(List<Paquete>)': recibe una lista de paquetes, la ordena por su peso 
 *   usando el orden natural (Comparable definido en Paquete) y devuelve la lista ordenada.
 */
