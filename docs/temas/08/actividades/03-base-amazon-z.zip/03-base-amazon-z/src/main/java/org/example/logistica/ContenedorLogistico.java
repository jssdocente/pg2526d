package org.example.logistica;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/*
 * EJERCICIO 6: Contenedor Genérico Inteligente
 * 
 * Esta clase debe ser GENÉRICA y permitir gestionar cualquier tipo de objeto
 * que implemente la interfaz Comparable.
 * 
 * Requisitos:
 * - Definición de la clase: ContenedorLogistico<T extends Comparable<T>>.
 * - Atributo privado: una lista de tipo T.
 * - Método 'añadir(T)': añade un elemento a la lista.
 * - Método 'obtenerMasImportante()': devuelve el elemento máximo según el orden natural de T.
 * - Método 'obtenerOrdenados()': devuelve la lista ordenada según el orden natural de T.
 */
