package org.example.logistica;

/*
 * EJERCICIO 4: Comparador de Código Postal
 * 
 * Clase que implementa la interfaz Comparator para definir un orden alternativo.
 * 
 * Requisitos:
 * - Implementar compare(Paquete, Paquete) para ordenar por código postal (String) de forma ASCENDENTE.
 */
