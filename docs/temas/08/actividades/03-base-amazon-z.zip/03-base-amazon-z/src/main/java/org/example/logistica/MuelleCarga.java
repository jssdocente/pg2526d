package org.example.logistica;

/*
 * EJERCICIO 1: Muelle de Carga (FIFO)
 * 
 * Esta clase gestiona la cinta transportadora donde los paquetes se cargan en orden de llegada.
 * 
 * Requisitos:
 * - Un atributo privado de tipo Queue<Paquete>.
 * - Método 'recibirPaquete(Paquete)': añade el paquete a la cola.
 * - Método 'cargarCamion()': extrae y devuelve el siguiente paquete de la cola (FIFO).
 */
